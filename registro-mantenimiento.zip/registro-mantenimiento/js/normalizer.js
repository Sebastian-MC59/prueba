/*
 * Normalización de nombres de cliente.
 * "Cinemark Plaza Norte", "CINEMARK  centro" y "cinémark" producen la misma marca raíz: CINEMARK.
 * "C.C.I. Torre Sur" → CCI, "Grupo GEA S.A." → GEA, "A.I.E Ingeniería" → AIE.
 */
window.MR = window.MR || {};

MR.normalizer = (() => {
  const C = MR.config;
  const IGNORADAS = new Set(C.palabrasIgnoradas);

  function tokens(name) {
    let s = String(name ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase();
    // Une siglas escritas con puntos: C.C.I. → CCI, A.I.E → AIE, S.A. → SA
    s = s.replace(/\b(?:[A-Z]\.){2,}[A-Z]?\.?/g, m => m.replace(/\./g, ''));
    s = s.replace(/[^A-Z0-9&]+/g, ' ').trim();
    return s ? s.split(' ') : [];
  }

  // Forma compacta de una marca para compararla: "Cine Mark" → "CINEMARK"
  const key = text => tokens(text).join('');

  /** Devuelve la marca raíz de un nombre usando la lista de marcas conocidas. */
  function rootOf(name, marcas = C.marcasRaiz) {
    const toks = tokens(name);
    if (!toks.length) return '';
    const known = marcas.map(key).filter(Boolean).sort((a, b) => b.length - a.length);

    // 1. Una palabra igual a una marca conocida, o que empieza por ella (CINEMARKCR)
    for (const t of toks) {
      const hit = known.find(m => t === m || (m.length >= 4 && t.startsWith(m)));
      if (hit) return hit;
    }
    // 2. La marca conocida escrita en varias palabras ("CINE MARK")
    const joined = toks.join('');
    const multi = known.find(m => m.length >= 4 && joined.includes(m));
    if (multi) return multi;

    // 3. Primera palabra significativa (ni genérica ni solo números)
    const significativa = toks.find(t => !IGNORADAS.has(t) && !/^\d+$/.test(t));
    return significativa || toks[0];
  }

  return { tokens, key, rootOf };
})();
