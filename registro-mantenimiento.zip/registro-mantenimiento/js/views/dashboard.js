/* Vista principal: resumen general y un contenedor independiente por año. */
window.MR = window.MR || {};
MR.views = MR.views || {};

MR.views.dashboard = {
  sorters: {
    nombre: (a, b) => a.nombre.localeCompare(b.nombre, 'es'),
    visitas: (a, b) => b.visitas - a.visitas || a.nombre.localeCompare(b.nombre, 'es'),
    informes: (a, b) => b.informes - a.informes || a.nombre.localeCompare(b.nombre, 'es'),
    reciente: (a, b) => (b.actualizado || '').localeCompare(a.actualizado || ''),
  },

  matches(c, q) {
    return MR.utils.matches(q, [
      c.nombre, c.root, ...c.variantes,
      ...c.equipos.flatMap(e => [e.categoria, e.especifico, e.capacidad !== null ? `${e.capacidad} ${e.unidad}` : '']),
    ]);
  },

  render(el) {
    const C = MR.config, U = MR.utils, S = MR.store;
    const { icon, options } = MR.ui;
    const q = MR.state.query;
    const all = S.clients();
    const totals = C.years.map(y => S.stats(y));
    const sum = k => totals.reduce((a, t) => a + t[k], 0);
    const marcasUnicas = new Set(all.map(c => c.root)).size;

    el.innerHTML = `
      <section class="overview">
        <div class="overview-text">
          <h1>Panel de mantenimiento</h1>
          <p class="text-muted">${U.plural(marcasUnicas, 'cliente único', 'clientes únicos')} en ${C.years.join(' y ')}.
            ${U.plural(sum('visitas'), 'visita', 'visitas')}, ${U.plural(sum('informes'), 'informe', 'informes')} y ${U.plural(sum('equipos'), 'equipo', 'equipos')} registrados.</p>
        </div>
        <label class="sort"><span class="text-muted">Ordenar por</span>
          <select data-sort>${options([['nombre', 'Nombre'], ['visitas', 'Más visitas'], ['informes', 'Más informes'], ['reciente', 'Actualizados recientemente']], MR.state.sort)}</select>
        </label>
      </section>
      ${q ? `<p class="search-summary">Resultados para «${U.esc(q)}» <button type="button" class="link-btn" data-action="clear-search">Limpiar búsqueda</button></p>` : ''}
      <div class="years">${C.years.map((y, i) => this.yearBlock(y, totals[i], i)).join('')}</div>`;

    el.querySelector('[data-sort]').addEventListener('change', e => { MR.state.sort = e.target.value; this.render(el); });

    // Si se está editando un nombre, enfocar el campo
    const editing = el.querySelector('[data-name-input]');
    if (editing) { editing.focus(); editing.select(); }
  },

  yearBlock(year, st, index) {
    const U = MR.utils, S = MR.store;
    const { icon } = MR.ui;
    const q = MR.state.query;
    const list = S.byYear(year);
    const rows = list.filter(c => this.matches(c, q)).sort(this.sorters[MR.state.sort] || this.sorters.nombre);

    const body = !list.length
      ? `<div class="year-empty"><p>Aún no hay registros en ${year}.</p>
          <button type="button" class="btn btn-secondary" data-action="new-record" data-year="${year}">${icon('plus')}Agregar registro</button></div>`
      : !rows.length
        ? `<div class="year-empty"><p>Ningún cliente de ${year} coincide con la búsqueda.</p></div>`
        : `<ul class="clients">${rows.map(c => this.card(c)).join('')}</ul>`;

    return `
      <section class="year year-${index % 2 ? 'b' : 'a'}" aria-labelledby="year-${year}">
        <header class="year-head">
          <h2 class="year-num" id="year-${year}">${year}</h2>
          <dl class="year-stats">
            <div><dt>Clientes</dt><dd>${U.fmtNum(st.clientes)}</dd></div>
            <div><dt>Visitas</dt><dd>${U.fmtNum(st.visitas)}</dd></div>
            <div><dt>Informes</dt><dd>${U.fmtNum(st.informes)}</dd></div>
            <div><dt>Equipos</dt><dd>${U.fmtNum(st.equipos)}</dd></div>
          </dl>
          <button type="button" class="btn btn-secondary btn-small year-add" data-action="new-record" data-year="${year}">${icon('plus')}Agregar registro</button>
        </header>
        ${q && list.length ? `<p class="year-count">${rows.length} de ${U.plural(list.length, 'cliente', 'clientes')}</p>` : ''}
        ${body}
      </section>`;
  },

  card(c) {
    const U = MR.utils, EQ = MR.equipmentField;
    const { icon } = MR.ui;
    const esc = U.esc;
    const q = MR.state.query;
    const editing = MR.state.editing === c.id;
    const variantes = c.variantes.filter(v => U.norm(v) !== U.norm(c.nombre));

    const name = editing
      ? `<div class="name-edit">
          <input data-name-input data-id="${c.id}" value="${esc(c.nombre)}" maxlength="100" aria-label="Nombre del cliente">
          <button type="button" class="icon-btn icon-ok" data-action="save-name" data-id="${c.id}" aria-label="Guardar nombre" title="Guardar (Enter)">${icon('check')}</button>
          <button type="button" class="icon-btn" data-action="cancel-name" aria-label="Cancelar" title="Cancelar (Esc)">${icon('x')}</button>
        </div>`
      : `<div class="name-row">
          <h3 class="client-name">${U.highlight(c.nombre, q)}</h3>
          <button type="button" class="icon-btn pencil admin-only" data-action="edit-name" data-id="${c.id}" aria-label="Editar nombre de ${esc(c.nombre)}" title="Editar nombre">${icon('edit')}</button>
        </div>`;

    return `<li class="client">
      <div class="client-head">
        <div class="client-id">
          ${name}
          <p class="client-meta">
            ${U.norm(c.root) !== U.norm(c.nombre) ? `<span class="root-chip">Marca raíz ${esc(c.root)}</span>` : ''}
            ${variantes.length ? `<span class="variants" title="${esc(variantes.join(', '))}">También como ${variantes.slice(0, 2).map(v => `«${U.highlight(v, q)}»`).join(', ')}${variantes.length > 2 ? ` y ${variantes.length - 2} más` : ''}</span>` : ''}
          </p>
        </div>
        <div class="metrics">
          <div><span class="metric-value">${U.fmtNum(c.visitas)}</span><span class="metric-label">Visitas</span></div>
          <div><span class="metric-value">${U.fmtNum(c.informes)}</span><span class="metric-label">Informes</span></div>
        </div>
      </div>
      ${c.equipos.length ? `<table class="equipos">
        <thead><tr><th>Equipo específico</th><th>Categoría</th><th class="num">Capacidad</th><th class="num">Cant.</th><th class="admin-only"><span class="sr-only">Acciones</span></th></tr></thead>
        <tbody>${c.equipos.map(e => `<tr>
          <td>${U.highlight(e.especifico, q)}</td>
          <td class="text-muted">${U.highlight(e.categoria, q)}</td>
          <td class="num cap">${U.highlight(EQ.formatCapacidad(e), q)}</td>
          <td class="num">${e.cantidad}</td>
          <td class="admin-only eq-actions">
            <button type="button" class="icon-btn small" data-action="edit-equipment" data-id="${c.id}" data-eq="${e.id}" aria-label="Editar ${esc(e.especifico)}">${icon('edit')}</button>
            <button type="button" class="icon-btn small" data-action="remove-equipment" data-id="${c.id}" data-eq="${e.id}" aria-label="Eliminar ${esc(e.especifico)}">${icon('trash')}</button>
          </td></tr>`).join('')}</tbody>
      </table>` : '<p class="no-equipos">Sin equipos registrados.</p>'}
      <div class="client-actions">
        <button type="button" class="link-btn" data-action="add-equipment" data-id="${c.id}">${icon('plus')}Agregar equipo</button>
        <button type="button" class="link-btn" data-action="history" data-id="${c.id}">${icon('history')}Historial</button>
        <button type="button" class="link-btn danger-text admin-only" data-action="delete-client" data-id="${c.id}">${icon('trash')}Eliminar</button>
      </div>
    </li>`;
  },
};
