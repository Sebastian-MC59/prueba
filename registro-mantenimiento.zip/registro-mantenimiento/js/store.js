/*
 * Estado central y reglas de negocio.
 * Un cliente es único por (año + marca raíz). Todo registro nuevo de la misma
 * marca raíz en el mismo año se fusiona: suma visitas e informes, guarda la
 * variante del nombre y agrega el equipo (sumando cantidad si ya existía).
 */
window.MR = window.MR || {};

MR.store = (() => {
  const C = MR.config, U = MR.utils, N = MR.normalizer;
  const blank = () => ({ version: 1, clients: [], marcas: [...C.marcasRaiz] });
  let data = blank();
  const listeners = new Set();

  const normalizeData = d => ({
    version: 1,
    clients: Array.isArray(d?.clients) ? d.clients : [],
    marcas: Array.isArray(d?.marcas) && d.marcas.length ? d.marcas : [...C.marcasRaiz],
  });
  const emit = () => listeners.forEach(fn => fn());
  const commit = () => { MR.storage.save(data); emit(); };
  const fail = m => { throw new Error(m); };

  async function init() {
    const loaded = await MR.storage.load();
    if (loaded) data = normalizeData(loaded);
    else seed(false);
    MR.storage.subscribe(next => { data = normalizeData(next); emit(); });
  }
  const subscribe = fn => { listeners.add(fn); return () => listeners.delete(fn); };

  /* ---------- Consultas ---------- */
  const clients = () => data.clients;
  const client = id => data.clients.find(c => c.id === id);
  const byYear = year => data.clients.filter(c => c.year === year);
  const marcas = () => [...data.marcas];
  const find = (year, root, exceptId) => data.clients.find(c => c.year === year && c.root === root && c.id !== exceptId);
  const rootOf = nombre => N.rootOf(nombre, data.marcas);

  function preview(nombre, year) {
    const root = rootOf(nombre);
    return root ? { root, existing: find(Number(year), root) || null } : null;
  }

  function stats(year) {
    const list = byYear(year);
    return {
      clientes: list.length,
      visitas: list.reduce((a, c) => a + c.visitas, 0),
      informes: list.reduce((a, c) => a + c.informes, 0),
      equipos: list.reduce((a, c) => a + c.equipos.reduce((s, e) => s + e.cantidad, 0), 0),
    };
  }

  /* ---------- Ayudantes internos ---------- */
  function toInt(v, label) {
    if (v === '' || v === null || v === undefined) return 0;
    const n = Number(v);
    if (!Number.isInteger(n) || n < 0) fail(`${label} debe ser un número entero igual o mayor que 0.`);
    return n;
  }

  // Valida el bloque Equipo; la capacidad solo tiene sentido con un equipo específico
  function cleanEquipo(e, required = false) {
    const categoria = String(e?.categoria ?? '').trim();
    const especifico = String(e?.especifico ?? '').trim();
    const capRaw = String(e?.capacidad ?? '').trim().replace(',', '.');
    if (!especifico) {
      if (capRaw) fail('Indica el equipo específico al que corresponde la capacidad.');
      if (required) fail('Indica el equipo específico.');
      return null;
    }
    let capacidad = null;
    if (capRaw) {
      capacidad = Number(capRaw);
      if (!Number.isFinite(capacidad) || capacidad < 0) fail('La capacidad debe ser un número igual o mayor que 0.');
    }
    return {
      categoria: categoria || 'Otro',
      especifico,
      capacidad,
      unidad: capacidad === null ? null : (e.unidad || C.unidadesCapacidad[0]),
      cantidad: Math.max(1, parseInt(e?.cantidad, 10) || 1),
    };
  }

  const eqKey = e => [U.norm(e.categoria), U.norm(e.especifico), e.capacidad ?? '', e.unidad ?? ''].join('|');
  function mergeEquipo(target, eq) {
    const same = target.equipos.find(x => eqKey(x) === eqKey(eq));
    if (same) { same.cantidad += eq.cantidad || 1; return same; }
    const item = { id: U.uid('e'), ...eq, cantidad: eq.cantidad || 1 };
    target.equipos.push(item);
    return item;
  }

  function addVariant(target, name) {
    const v = String(name ?? '').trim();
    if (v && !target.variantes.some(x => U.norm(x) === U.norm(v))) target.variantes.push(v);
  }

  const log = (target, tipo, detalle) => target.historial.push({ fecha: U.today(), tipo, detalle });

  // Pasa todo lo de source a target y elimina source
  function absorb(target, source) {
    target.visitas += source.visitas;
    target.informes += source.informes;
    addVariant(target, source.nombre);
    source.variantes.forEach(v => addVariant(target, v));
    source.equipos.forEach(e => mergeEquipo(target, { ...e }));
    target.historial.push(...source.historial);
    log(target, 'fusion', `Fusionado con ${source.nombre}: +${source.visitas} visitas, +${source.informes} informes`);
    target.actualizado = U.today();
    data.clients = data.clients.filter(c => c.id !== source.id);
  }

  /* ---------- Acciones ---------- */
  function addRecord(input, { silent = false } = {}) {
    const nombre = String(input.nombre ?? '').trim();
    if (!nombre) fail('Escribe el nombre del cliente.');
    const year = Number(input.year);
    if (!C.years.includes(year)) fail('Selecciona un año válido.');
    const root = rootOf(nombre) || fail('El nombre debe contener letras o números.');
    const visitas = toInt(input.visitas, 'Visitas');
    const informes = toInt(input.informes, 'Informes');
    const equipo = cleanEquipo(input.equipo);

    let target = find(year, root);
    const merged = Boolean(target);
    if (!target) {
      target = { id: U.uid('c'), year, root, nombre: root, variantes: [], visitas: 0, informes: 0, equipos: [], historial: [], creado: U.today(), actualizado: U.today() };
      data.clients.push(target);
    }
    target.visitas += visitas;
    target.informes += informes;
    addVariant(target, nombre);
    if (equipo) mergeEquipo(target, equipo);
    log(target, merged ? 'fusion' : 'alta', `${nombre}: +${visitas} visitas, +${informes} informes${equipo ? `, ${equipo.especifico}${equipo.capacidad !== null ? ` ${U.fmtNum(equipo.capacidad)} ${equipo.unidad}` : ''}` : ''}`);
    target.actualizado = U.today();
    if (!silent) commit();
    return { client: target, merged };
  }

  function addEquipment(clientId, equipo) {
    const target = client(clientId) || fail('El cliente ya no existe.');
    const eq = cleanEquipo(equipo, true);
    const item = mergeEquipo(target, eq);
    log(target, 'equipo', `Equipo agregado: ${eq.especifico}${eq.capacidad !== null ? ` ${U.fmtNum(eq.capacidad)} ${eq.unidad}` : ''}`);
    target.actualizado = U.today();
    commit();
    return item;
  }

  function updateEquipment(clientId, eqId, equipo) {
    const target = client(clientId) || fail('El cliente ya no existe.');
    const item = target.equipos.find(e => e.id === eqId) || fail('El equipo ya no existe.');
    const eq = cleanEquipo({ ...equipo, cantidad: item.cantidad }, true);
    const cantidad = toInt(equipo.cantidad, 'Cantidad') || 1;
    target.equipos = target.equipos.filter(e => e.id !== eqId);
    const merged = mergeEquipo(target, { ...eq, cantidad });
    log(target, 'equipo', `Equipo actualizado: ${eq.especifico}`);
    commit();
    return merged;
  }

  function removeEquipment(clientId, eqId) {
    const target = client(clientId);
    if (!target) return;
    const item = target.equipos.find(e => e.id === eqId);
    target.equipos = target.equipos.filter(e => e.id !== eqId);
    if (item) log(target, 'equipo', `Equipo eliminado: ${item.especifico}`);
    commit();
  }

  /**
   * Cambia el nombre visible. Si el nuevo nombre lleva a una marca raíz que ya
   * existe en el mismo año, devuelve { conflict } salvo que se pida merge: true.
   */
  function renameClient(id, newName, { merge = false } = {}) {
    const target = client(id) || fail('El cliente ya no existe.');
    const nombre = String(newName ?? '').trim();
    if (!nombre) fail('El nombre no puede quedar vacío.');
    const root = rootOf(nombre) || fail('El nombre debe contener letras o números.');
    const other = find(target.year, root, target.id);
    if (other && !merge) return { conflict: other, root };
    if (nombre !== target.nombre) log(target, 'edicion', `Nombre cambiado de ${target.nombre} a ${nombre}`);
    target.nombre = nombre;
    target.root = root;
    target.actualizado = U.today();
    if (other) absorb(target, other);
    commit();
    return { client: target, merged: Boolean(other) };
  }

  function deleteClient(id) {
    data.clients = data.clients.filter(c => c.id !== id);
    commit();
  }

  /* ---------- Marcas raíz (administración) ---------- */
  function addMarca(text) {
    const m = N.key(text);
    if (!m) fail('Escribe una marca con letras o números.');
    if (data.marcas.includes(m)) fail(`${m} ya está en la lista.`);
    data.marcas.push(m);
    commit();
    return m;
  }
  function removeMarca(m) { data.marcas = data.marcas.filter(x => x !== m); commit(); }

  // Recalcula la marca raíz de los registros existentes y fusiona duplicados por año
  function regroup() {
    let cambios = 0, fusiones = 0;
    data.clients.forEach(c => {
      const r = rootOf(c.variantes[0] || c.nombre);
      if (r && r !== c.root) {
        if (c.nombre === c.root) c.nombre = r;
        c.root = r;
        cambios++;
      }
    });
    C.years.forEach(y => {
      const seen = {};
      byYear(y).forEach(c => {
        if (seen[c.root]) { absorb(seen[c.root], c); fusiones++; } else seen[c.root] = c;
      });
    });
    commit();
    return { cambios, fusiones };
  }

  /* ---------- Respaldo ---------- */
  function seed(notify = true) {
    data = blank();
    MR.seedRecords.forEach(r => addRecord(r, { silent: true }));
    MR.storage.save(data);
    if (notify) emit();
  }
  const exportJSON = () => JSON.stringify({ ...data, exportado: new Date().toISOString() }, null, 2);
  function importJSON(raw) {
    let parsed;
    try { parsed = JSON.parse(raw); } catch { fail('El archivo no es un JSON válido.'); }
    if (!Array.isArray(parsed?.clients)) fail('El archivo no tiene el formato de respaldo de esta app.');
    data = normalizeData(parsed);
    commit();
  }
  const clearAll = () => { data = blank(); commit(); };

  return {
    init, subscribe, clients, client, byYear, marcas, preview, stats, rootOf,
    addRecord, addEquipment, updateEquipment, removeEquipment, renameClient, deleteClient,
    addMarca, removeMarca, regroup, loadDemo: () => seed(true), exportJSON, importJSON, clearAll,
  };
})();
