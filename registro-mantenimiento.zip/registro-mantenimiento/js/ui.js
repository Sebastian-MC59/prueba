/* Piezas de interfaz: íconos, campos, modal, confirmación y avisos. */
window.MR = window.MR || {};

MR.ui = (() => {
  const U = MR.utils;
  const icon = name => `<svg class="i" aria-hidden="true"><use href="#i-${name}"></use></svg>`;

  const field = (label, control, { hint = '', full = false, cls = '' } = {}) =>
    `<label class="field${full ? ' full' : ''}${cls ? ` ${cls}` : ''}"><span class="field-label">${label}</span>${control}${hint ? `<span class="hint">${hint}</span>` : ''}</label>`;

  const options = (list, selected) => list.map(o => {
    const [v, l] = Array.isArray(o) ? o : [o, o];
    return `<option value="${U.esc(v)}"${String(v) === String(selected) ? ' selected' : ''}>${U.esc(l)}</option>`;
  }).join('');

  /* ---------- Modal ---------- */
  const root = () => document.getElementById('modal-root');
  let lastFocus = null;
  const onKey = e => { if (e.key === 'Escape') closeModal(); };

  function closeModal() {
    const r = root();
    if (!r.classList.contains('open')) return;
    r.classList.remove('open');
    r.innerHTML = '';
    document.removeEventListener('keydown', onKey);
    document.body.classList.remove('no-scroll');
    if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
  }

  function openModal({ title, subtitle = '', body, submitLabel = 'Guardar', onSubmit = null, size = 'md', danger = false, footer = null }) {
    const r = root();
    if (!r.classList.contains('open')) lastFocus = document.activeElement;
    document.removeEventListener('keydown', onKey);
    r.innerHTML = `
      <div class="modal-backdrop" data-close></div>
      <div class="modal modal-${size}" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <form class="modal-form">
          <header class="modal-head">
            <div><h2 id="modal-title">${title}</h2>${subtitle ? `<p class="modal-sub">${subtitle}</p>` : ''}</div>
            <button type="button" class="icon-btn" data-close aria-label="Cerrar">${icon('x')}</button>
          </header>
          <div class="modal-body">${body}</div>
          <p class="form-error" role="alert" hidden></p>
          <footer class="modal-foot">${footer ?? `
            <button type="button" class="btn btn-ghost" data-close>Cancelar</button>
            ${onSubmit ? `<button type="submit" class="btn ${danger ? 'btn-danger' : 'btn-primary'}">${submitLabel}</button>` : ''}`}
          </footer>
        </form>
      </div>`;
    r.classList.add('open');
    document.body.classList.add('no-scroll');
    document.addEventListener('keydown', onKey);

    const form = r.querySelector('form');
    const error = r.querySelector('.form-error');
    r.querySelectorAll('[data-close]').forEach(el => el.addEventListener('click', closeModal));
    form.addEventListener('submit', e => {
      e.preventDefault();
      if (!onSubmit) return closeModal();
      try {
        const result = onSubmit(Object.fromEntries(new FormData(form)), form);
        if (result !== false) closeModal();
      } catch (err) {
        error.textContent = err.message;
        error.hidden = false;
      }
    });
    requestAnimationFrame(() => {
      (form.querySelector('[autofocus]') || form.querySelector('input:not([type=hidden]):not([type=radio]), select, textarea') || form.querySelector('button'))?.focus();
    });
    return r.querySelector('.modal');
  }

  function confirmDialog({ title, text, confirmLabel = 'Confirmar', danger = false }) {
    return new Promise(resolve => {
      let answered = false;
      openModal({ title, body: `<p>${text}</p>`, submitLabel: confirmLabel, danger, size: 'sm', onSubmit: () => { answered = true; resolve(true); } });
      const obs = new MutationObserver(() => {
        if (!root().classList.contains('open')) { obs.disconnect(); if (!answered) resolve(false); }
      });
      obs.observe(root(), { attributes: true, attributeFilter: ['class'] });
    });
  }

  function toast(message, tone = 'ok') {
    const el = document.createElement('div');
    el.className = `toast tone-${tone}`;
    el.textContent = message;
    document.getElementById('toast-root').appendChild(el);
    setTimeout(() => el.classList.add('leaving'), 2800);
    setTimeout(() => el.remove(), 3200);
  }

  return { icon, field, options, openModal, closeModal, confirmDialog, toast };
})();
