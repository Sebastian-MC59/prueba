/* Formularios: nuevo registro, equipos, historial y administración. */
window.MR = window.MR || {};

MR.forms = (() => {
  const C = MR.config, U = MR.utils, S = MR.store, EQ = MR.equipmentField;
  const { field, openModal, closeModal, confirmDialog, toast, icon } = MR.ui;
  const esc = U.esc;

  /* ---------- Nuevo registro ---------- */
  function newRecord(presetYear) {
    const year = C.years.includes(Number(presetYear)) ? Number(presetYear) : (C.years.includes(new Date().getFullYear()) ? new Date().getFullYear() : C.years[0]);
    const nombres = [...new Set(S.clients().flatMap(c => [c.nombre, ...c.variantes]))].sort((a, b) => a.localeCompare(b, 'es'));

    const body = `
      ${field('Cliente', `<input name="nombre" required maxlength="100" list="clientes-conocidos" autocomplete="off" placeholder="Ej. Cinemark Plaza Norte" autofocus>
        <datalist id="clientes-conocidos">${nombres.map(n => `<option value="${esc(n)}">`).join('')}</datalist>`, { full: true })}
      <div class="normalize-preview" data-preview aria-live="polite"></div>
      <fieldset class="segmented">
        <legend class="field-label">Año</legend>
        ${C.years.map(y => `<label><input type="radio" name="year" value="${y}" ${y === year ? 'checked' : ''}><span>${y}</span></label>`).join('')}
      </fieldset>
      <div class="grid-2">
        ${field('Visitas', '<input name="visitas" type="number" min="0" step="1" value="1" required>')}
        ${field('Informes', '<input name="informes" type="number" min="0" step="1" value="0" required>')}
      </div>
      ${EQ.render()}`;

    const modal = openModal({
      title: 'Nuevo registro', subtitle: 'Los nombres se agrupan por su marca raíz para evitar duplicados',
      body, size: 'lg', submitLabel: 'Guardar registro',
      onSubmit: v => {
        const { client, merged } = S.addRecord({ nombre: v.nombre, year: v.year, visitas: v.visitas, informes: v.informes, equipo: EQ.read(v) });
        toast(merged ? `Fusionado con ${client.nombre} (${client.year})` : `${client.nombre} registrado en ${client.year}`);
      },
    });
    EQ.bind(modal);

    const nameInput = modal.querySelector('[name=nombre]');
    const box = modal.querySelector('[data-preview]');
    const update = () => {
      const y = Number(modal.querySelector('[name=year]:checked').value);
      const p = S.preview(nameInput.value, y);
      if (!p) { box.innerHTML = ''; box.className = 'normalize-preview'; return; }
      if (p.existing) {
        box.className = 'normalize-preview is-merge';
        box.innerHTML = `${icon('merge')}<span>Se agrupa como <strong>${esc(p.root)}</strong>. Ya existe en ${y} como «${esc(p.existing.nombre)}»: se sumarán las visitas e informes (hoy ${U.plural(p.existing.visitas, 'visita', 'visitas')}, ${U.plural(p.existing.informes, 'informe', 'informes')}).</span>`;
      } else {
        box.className = 'normalize-preview is-new';
        box.innerHTML = `${icon('plus')}<span>Cliente nuevo en ${y} con la marca raíz <strong>${esc(p.root)}</strong>.</span>`;
      }
    };
    nameInput.addEventListener('input', U.debounce(update, 60));
    modal.querySelectorAll('[name=year]').forEach(r => r.addEventListener('change', update));
  }

  /* ---------- Equipos ---------- */
  function addEquipment(clientId) {
    const c = S.client(clientId);
    if (!c) return;
    const modal = openModal({
      title: 'Agregar equipo', subtitle: `${esc(c.nombre)}, ${c.year}`,
      body: EQ.render({ optional: false, withCantidad: true }), size: 'lg', submitLabel: 'Agregar equipo',
      onSubmit: v => { const e = S.addEquipment(c.id, EQ.read(v)); toast(`${e.especifico} agregado a ${c.nombre}`); },
    });
    EQ.bind(modal);
  }

  function editEquipment(clientId, eqId) {
    const c = S.client(clientId);
    const e = c?.equipos.find(x => x.id === eqId);
    if (!e) return;
    const modal = openModal({
      title: 'Editar equipo', subtitle: `${esc(c.nombre)}, ${c.year}`,
      body: EQ.render({ value: e, optional: false, withCantidad: true }), size: 'lg', submitLabel: 'Guardar cambios',
      onSubmit: v => { S.updateEquipment(c.id, e.id, EQ.read(v)); toast('Equipo actualizado'); },
    });
    EQ.bind(modal);
  }

  async function removeEquipment(clientId, eqId) {
    const c = S.client(clientId);
    const e = c?.equipos.find(x => x.id === eqId);
    if (!e) return;
    const ok = await confirmDialog({ title: 'Eliminar equipo', text: `Se quitará <strong>${esc(e.especifico)}</strong> (${esc(EQ.formatCapacidad(e))}) de ${esc(c.nombre)}.`, confirmLabel: 'Eliminar', danger: true });
    if (ok) { S.removeEquipment(c.id, e.id); toast('Equipo eliminado'); }
  }

  /* ---------- Historial y variantes ---------- */
  function history(clientId) {
    const c = S.client(clientId);
    if (!c) return;
    const variantes = c.variantes.filter(v => U.norm(v) !== U.norm(c.nombre));
    const labels = { alta: 'Alta', fusion: 'Fusión', edicion: 'Edición', equipo: 'Equipo' };
    openModal({
      title: esc(c.nombre), subtitle: `Marca raíz ${esc(c.root)}, año ${c.year}`, size: 'md',
      body: `
        <h3 class="sub-title">Nombres registrados</h3>
        ${variantes.length ? `<ul class="chips">${variantes.map(v => `<li>${esc(v)}</li>`).join('')}</ul>` : '<p class="text-muted">Solo se ha registrado con este nombre.</p>'}
        <h3 class="sub-title">Historial</h3>
        <ol class="timeline">${[...c.historial].reverse().map(h => `<li class="ev-${h.tipo}">
          <span class="ev-date">${U.fmtDate(h.fecha)}</span><div><strong>${labels[h.tipo] || h.tipo}</strong><p>${esc(h.detalle)}</p></div></li>`).join('')}</ol>`,
      footer: '<button type="button" class="btn btn-ghost" data-close>Cerrar</button>',
    });
  }

  /* ---------- Administración ---------- */
  function adminLogin(onSuccess) {
    openModal({
      title: 'Modo administrador', subtitle: 'Permite editar nombres, fusionar y eliminar registros',
      size: 'sm', submitLabel: 'Entrar',
      body: field('PIN', '<input name="pin" type="password" inputmode="numeric" autocomplete="off" required autofocus>', { hint: 'PIN inicial: 1234. Cámbialo en js/config.js.' }),
      onSubmit: v => {
        if (v.pin !== C.adminPin) throw new Error('PIN incorrecto.');
        onSuccess();
      },
    });
  }

  function adminPanel() {
    const marcas = S.marcas();
    const modal = openModal({
      title: 'Administración', size: 'md',
      body: `
        <h3 class="sub-title">Marcas raíz</h3>
        <p class="text-muted">Cualquier nombre que contenga una de estas marcas se agrupa bajo ella, aunque esté escrito con tildes, mayúsculas, puntos o sucursal.</p>
        <ul class="chips chips-removable">${marcas.map(m => `<li>${esc(m)}<button type="button" class="chip-x" data-action="remove-marca" data-marca="${esc(m)}" aria-label="Quitar ${esc(m)}">${icon('x')}</button></li>`).join('')}</ul>
        <div class="inline-add">
          <input name="marca" maxlength="40" placeholder="Nueva marca, ej. WALMART" aria-label="Nueva marca raíz">
          <button type="button" class="btn btn-secondary" data-action="add-marca">${icon('plus')}Agregar</button>
        </div>
        <div class="admin-row">
          <div><strong>Reagrupar registros existentes</strong><p class="text-muted">Aplica las marcas actuales a todos los clientes y fusiona los duplicados de cada año.</p></div>
          <button type="button" class="btn btn-secondary" data-action="regroup">${icon('merge')}Reagrupar</button>
        </div>
        <h3 class="sub-title">Datos</h3>
        <div class="admin-actions">
          <button type="button" class="btn btn-secondary" data-action="export">Exportar respaldo</button>
          <label class="btn btn-secondary">Importar respaldo<input type="file" accept="application/json,.json" data-import hidden></label>
          <button type="button" class="btn btn-ghost" data-action="reset-demo">Cargar datos de ejemplo</button>
          <button type="button" class="btn btn-ghost danger-text" data-action="clear-all">Borrar todo</button>
        </div>`,
      footer: '<button type="button" class="btn btn-ghost" data-close>Cerrar</button>',
    });

    const input = modal.querySelector('[name=marca]');
    const add = () => {
      try { const m = S.addMarca(input.value); toast(`${m} agregada. Usa Reagrupar para aplicarla a registros anteriores.`); adminPanel(); }
      catch (err) { toast(err.message, 'danger'); }
    };
    input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); add(); } });
    modal.querySelector('[data-action=add-marca]').addEventListener('click', e => { e.stopPropagation(); add(); });
    modal.querySelector('[data-import]').addEventListener('change', async e => {
      const file = e.target.files[0];
      if (!file) return;
      try { S.importJSON(await file.text()); toast('Respaldo importado'); closeModal(); }
      catch (err) { toast(err.message, 'danger'); }
    });
  }

  return { newRecord, addEquipment, editEquipment, removeEquipment, history, adminLogin, adminPanel };
})();
