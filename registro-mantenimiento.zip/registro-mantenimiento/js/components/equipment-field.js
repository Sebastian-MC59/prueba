/*
 * Bloque "Equipo": categoría, y en la misma fila "Equipo específico" + "Capacidad" (valor y unidad).
 * render() devuelve el HTML, bind() activa las sugerencias y read() entrega el objeto listo
 * para el store: { categoria, especifico, capacidad, unidad }.
 */
window.MR = window.MR || {};

MR.equipmentField = (() => {
  const C = MR.config, U = MR.utils;
  const { options } = MR.ui;
  let counter = 0;

  function render({ value = null, optional = true, withCantidad = false } = {}) {
    const n = ++counter;
    const categorias = Object.keys(C.categoriasEquipo);
    const cat = value?.categoria || categorias[0];
    const unidad = value?.unidad || C.unidadPorCategoria[cat] || C.unidadesCapacidad[0];
    return `
      <fieldset class="equipo-section" data-equipo>
        <legend>Equipo${optional ? ' <span class="text-muted">(opcional)</span>' : ''}</legend>
        <div class="equipo-grid">
          <label class="field">
            <span class="field-label">Categoría de equipo</span>
            <select name="equipoCategoria" data-eq-cat>${options(categorias, cat)}</select>
          </label>
          <div class="equipo-capacidad-fila">
            <label class="field equipo-especifico">
              <span class="field-label">Equipo específico</span>
              <input name="equipoEspecifico" list="eq-sugerencias-${n}" autocomplete="off" maxlength="80"
                value="${U.esc(value?.especifico || '')}" placeholder="Chiller, UMA, planta eléctrica" ${optional ? '' : 'required'} data-eq-spec>
              <datalist id="eq-sugerencias-${n}" data-eq-list></datalist>
            </label>
            <div class="field campo-capacidad">
              <label class="field-label" for="eq-capacidad-${n}">Capacidad</label>
              <div class="capacidad-grupo">
                <input id="eq-capacidad-${n}" name="capacidad" type="number" min="0" step="any" inputmode="decimal"
                  value="${value?.capacidad ?? ''}" placeholder="Ej. 120" data-eq-cap>
                <select name="capacidadUnidad" aria-label="Unidad de capacidad" data-eq-unit>${options(C.unidadesCapacidad, unidad)}</select>
              </div>
            </div>
            ${withCantidad ? `<label class="field campo-cantidad"><span class="field-label">Cantidad</span>
              <input name="equipoCantidad" type="number" min="1" step="1" value="${value?.cantidad || 1}"></label>` : ''}
          </div>
        </div>
      </fieldset>`;
  }

  function bind(scope) {
    const box = scope.querySelector('[data-equipo]');
    if (!box) return;
    const cat = box.querySelector('[data-eq-cat]');
    const list = box.querySelector('[data-eq-list]');
    const unit = box.querySelector('[data-eq-unit]');
    let unitTouched = Boolean(box.querySelector('[data-eq-cap]').value);
    unit.addEventListener('change', () => { unitTouched = true; });
    const update = () => {
      list.innerHTML = (C.categoriasEquipo[cat.value] || []).map(s => `<option value="${U.esc(s)}">`).join('');
      if (!unitTouched && C.unidadPorCategoria[cat.value]) unit.value = C.unidadPorCategoria[cat.value];
    };
    cat.addEventListener('change', update);
    update();
  }

  // Lee los valores del FormData del formulario
  const read = values => ({
    categoria: values.equipoCategoria,
    especifico: values.equipoEspecifico,
    capacidad: values.capacidad,
    unidad: values.capacidadUnidad,
    cantidad: values.equipoCantidad,
  });

  // Texto legible de la capacidad
  const formatCapacidad = e => (e?.capacidad !== null && e?.capacidad !== undefined ? `${U.fmtNum(e.capacidad)} ${e.unidad}` : '—');

  return { render, bind, read, formatCapacidad };
})();
