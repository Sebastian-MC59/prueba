/* Utilidades: texto, búsqueda sin tildes, resaltado, fechas y formato. */
window.MR = window.MR || {};

MR.utils = (() => {
  const stripChar = ch => ch.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().charAt(0) || ch;
  const norm = v => String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();

  const esc = v => String(v ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const terms = q => norm(q).split(' ').filter(Boolean);

  // Todas las palabras buscadas deben aparecer en algún campo
  const matches = (query, fields) => {
    const t = terms(query);
    if (!t.length) return true;
    const hay = norm(fields.filter(v => v !== null && v !== undefined).join(' '));
    return t.every(x => hay.includes(x));
  };

  // Envuelve en <mark> las coincidencias, respetando tildes del texto original
  function highlight(text, query) {
    const t = terms(query);
    const chars = [...String(text ?? '')];
    if (!t.length) return esc(text);
    const flat = chars.map(stripChar).join('');
    const mark = new Array(chars.length).fill(false);
    t.forEach(term => {
      let i = flat.indexOf(term);
      while (i !== -1) { for (let k = i; k < i + term.length; k++) mark[k] = true; i = flat.indexOf(term, i + term.length); }
    });
    let out = '', open = false;
    chars.forEach((c, i) => {
      if (mark[i] && !open) { out += '<mark>'; open = true; }
      if (!mark[i] && open) { out += '</mark>'; open = false; }
      out += esc(c);
    });
    return open ? out + '</mark>' : out;
  }

  const pad = n => String(n).padStart(2, '0');
  const today = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
  const dateFmt = new Intl.DateTimeFormat('es', { day: 'numeric', month: 'short', year: 'numeric' });
  const fmtDate = iso => { if (!iso) return '—'; const [y, m, d] = iso.split('-').map(Number); return dateFmt.format(new Date(y, m - 1, d)); };
  const numFmt = new Intl.NumberFormat('es', { maximumFractionDigits: 2 });
  const fmtNum = n => numFmt.format(n);

  const uid = p => `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
  const debounce = (fn, ms = 80) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  const plural = (n, one, many) => `${fmtNum(n)} ${n === 1 ? one : many}`;

  return { norm, esc, matches, highlight, today, fmtDate, fmtNum, uid, debounce, plural };
})();
