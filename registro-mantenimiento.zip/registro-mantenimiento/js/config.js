/* Configuración y catálogos editables. */
window.MR = window.MR || {};

MR.config = {
  STORAGE_KEY: 'registro.mantenimiento.v1',

  // Cada año genera su propio contenedor en el panel
  years: [2026, 2027],

  // PIN del modo administrador. Es solo una barrera de uso en el navegador,
  // no un control de seguridad: para producción, valida el rol en el servidor.
  adminPin: '1234',

  // Marcas raíz conocidas: cualquier nombre que las contenga se agrupa bajo ellas.
  // Se pueden ampliar desde el panel de administración.
  marcasRaiz: ['CINEMARK', 'CCI', 'AIE', 'GEA'],

  // Palabras que no cuentan como marca al extraer la raíz de un nombre nuevo
  palabrasIgnoradas: [
    'S', 'A', 'SA', 'SRL', 'LTDA', 'LTD', 'INC', 'CORP', 'CORPORACION', 'CIA', 'COMPANIA', 'SOCIEDAD', 'ANONIMA',
    'GRUPO', 'EMPRESA', 'COMERCIAL', 'INTERNACIONAL', 'SUCURSAL', 'SEDE', 'TIENDA', 'OFICINA', 'OFICINAS',
    'HOTEL', 'HOSPITAL', 'CLINICA', 'CENTRO', 'PLAZA', 'MALL', 'EDIFICIO', 'CONDOMINIO', 'BANCO', 'TORRE',
    'DE', 'DEL', 'LA', 'LAS', 'EL', 'LOS', 'Y', 'E', 'EN', 'THE', 'AND', 'OF', 'CO',
  ],

  // Categorías de equipo y sugerencias para "Equipo específico"
  categoriasEquipo: {
    'Climatización': ['Chiller', 'Unidad manejadora (UMA)', 'Fan coil', 'Equipo paquete', 'Mini split', 'Condensadora', 'Torre de enfriamiento'],
    'Refrigeración': ['Cámara de frío', 'Compresor', 'Evaporador', 'Rack de refrigeración'],
    'Eléctrico': ['Tablero eléctrico', 'Transformador', 'UPS', 'Banco de capacitores'],
    'Generación': ['Planta eléctrica', 'Transferencia automática'],
    'Bombeo': ['Bomba de agua', 'Sistema hidroneumático', 'Bomba contra incendio'],
    'Ventilación': ['Extractor', 'Inyector de aire'],
    'Otro': [],
  },

  unidadesCapacidad: ['TR', 'kW', 'BTU/h', 'HP', 'kVA', 'A', 'L', 'm³/h', 'CFM', 'unidades'],

  // Unidad que se propone al elegir una categoría
  unidadPorCategoria: {
    'Climatización': 'TR', 'Refrigeración': 'kW', 'Eléctrico': 'kVA', 'Generación': 'kVA',
    'Bombeo': 'HP', 'Ventilación': 'CFM', 'Otro': 'unidades',
  },
};
