/*
 * Registros de ejemplo. Se cargan a través de la misma lógica de alta,
 * así que las variantes de un mismo cliente se fusionan como en el uso real.
 */
window.MR = window.MR || {};

MR.seedRecords = [
  { year: 2026, nombre: 'Cinemark Plaza Norte', visitas: 3, informes: 2, equipo: { categoria: 'Climatización', especifico: 'Chiller', capacidad: 120, unidad: 'TR' } },
  { year: 2026, nombre: 'CINEMARK centro', visitas: 2, informes: 1, equipo: { categoria: 'Climatización', especifico: 'Unidad manejadora (UMA)', capacidad: 15, unidad: 'TR' } },
  { year: 2026, nombre: 'cinémark', visitas: 1, informes: 1, equipo: { categoria: 'Climatización', especifico: 'Chiller', capacidad: 120, unidad: 'TR' } },
  { year: 2026, nombre: 'C.C.I. Torre Sur', visitas: 4, informes: 4, equipo: { categoria: 'Generación', especifico: 'Planta eléctrica', capacidad: 500, unidad: 'kVA' } },
  { year: 2026, nombre: 'CCI Oficinas Centrales', visitas: 1, informes: 0, equipo: { categoria: 'Eléctrico', especifico: 'UPS', capacidad: 30, unidad: 'kVA' } },
  { year: 2026, nombre: 'Grupo GEA S.A.', visitas: 2, informes: 1, equipo: { categoria: 'Bombeo', especifico: 'Bomba de agua', capacidad: 10, unidad: 'HP' } },
  { year: 2026, nombre: 'A.I.E Ingeniería', visitas: 1, informes: 1, equipo: { categoria: 'Eléctrico', especifico: 'Tablero eléctrico', capacidad: 400, unidad: 'A' } },
  { year: 2026, nombre: 'Hotel Barceló Centro', visitas: 2, informes: 2, equipo: { categoria: 'Refrigeración', especifico: 'Cámara de frío', capacidad: 12, unidad: 'kW' } },
  { year: 2027, nombre: 'CINEMARK', visitas: 1, informes: 0, equipo: { categoria: 'Climatización', especifico: 'Chiller', capacidad: 120, unidad: 'TR' } },
  { year: 2027, nombre: 'cci torre sur', visitas: 2, informes: 1, equipo: { categoria: 'Generación', especifico: 'Planta eléctrica', capacidad: 500, unidad: 'kVA' } },
  { year: 2027, nombre: 'GEA', visitas: 1, informes: 1, equipo: null },
];
