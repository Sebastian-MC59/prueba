/* Arranque: estado de la vista, búsqueda en tiempo real, modo administrador y acciones. */
window.MR = window.MR || {};

(() => {
  const S = MR.store, U = MR.utils, F = MR.forms;
  const { toast, confirmDialog, closeModal } = MR.ui;
  const ADMIN_KEY = 'registro.mantenimiento.admin';

  MR.state = {
    query: '',
    sort: 'nombre',
    editing: null,
    admin: sessionStorage.getItem(ADMIN_KEY) === '1',
  };

  const view = document.getElementById('view');
  const search = document.getElementById('search');
  const render = () => MR.views.dashboard.render(view);

  function setAdmin(on) {
    MR.state.admin = on;
    if (!on) MR.state.editing = null;
    on ? sessionStorage.setItem(ADMIN_KEY, '1') : sessionStorage.removeItem(ADMIN_KEY);
    document.body.classList.toggle('is-admin', on);
    const btn = document.getElementById('admin-toggle');
    btn.setAttribute('aria-pressed', String(on));
    btn.classList.toggle('is-on', on);
    btn.querySelector('use').setAttribute('href', on ? '#i-unlock' : '#i-lock');
    btn.querySelector('span').textContent = on ? 'Salir de administrador' : 'Modo administrador';
    render();
  }

  /* Búsqueda en tiempo real */
  search.addEventListener('input', U.debounce(() => { MR.state.query = search.value; render(); }, 60));
  search.addEventListener('keydown', e => { if (e.key === 'Escape') { search.value = ''; MR.state.query = ''; render(); } });

  /* Edición del nombre en línea */
  async function saveName(id) {
    const input = view.querySelector(`[data-name-input][data-id="${id}"]`);
    if (!input) return;
    const value = input.value;
    const c = S.client(id);
    MR.state.editing = null;
    try {
      const r = S.renameClient(id, value);
      if (r.conflict) {
        const ok = await confirmDialog({
          title: 'Fusionar registros',
          text: `«${U.esc(value.trim())}» corresponde a la marca raíz <strong>${U.esc(r.root)}</strong>, que ya existe en ${c.year} como «${U.esc(r.conflict.nombre)}». Si continúas, ambos registros se unirán y se sumarán sus visitas, informes y equipos.`,
          confirmLabel: 'Fusionar registros',
        });
        if (ok) { S.renameClient(id, value, { merge: true }); toast('Registros fusionados'); }
        else render();
      } else {
        toast('Nombre actualizado');
      }
    } catch (err) {
      MR.state.editing = id;
      render();
      toast(err.message, 'danger');
    }
  }

  view.addEventListener('keydown', e => {
    const input = e.target.closest('[data-name-input]');
    if (!input) return;
    if (e.key === 'Enter') { e.preventDefault(); saveName(input.dataset.id); }
    if (e.key === 'Escape') { e.stopPropagation(); MR.state.editing = null; render(); }
  });

  const requireAdmin = fn => el => { if (MR.state.admin) fn(el); else toast('Activa el modo administrador para esta acción.', 'warn'); };

  const actions = {
    'new-record': el => F.newRecord(el.dataset.year),
    'add-equipment': el => F.addEquipment(el.dataset.id),
    'history': el => F.history(el.dataset.id),
    'clear-search': () => { search.value = ''; MR.state.query = ''; render(); },
    'toggle-admin': () => (MR.state.admin ? setAdmin(false) : F.adminLogin(() => { setAdmin(true); toast('Modo administrador activo'); })),
    'admin-panel': requireAdmin(() => F.adminPanel()),
    'edit-name': requireAdmin(el => { MR.state.editing = el.dataset.id; render(); }),
    'save-name': requireAdmin(el => saveName(el.dataset.id)),
    'cancel-name': () => { MR.state.editing = null; render(); },
    'edit-equipment': requireAdmin(el => F.editEquipment(el.dataset.id, el.dataset.eq)),
    'remove-equipment': requireAdmin(el => F.removeEquipment(el.dataset.id, el.dataset.eq)),
    'delete-client': requireAdmin(async el => {
      const c = S.client(el.dataset.id);
      if (!c) return;
      const ok = await confirmDialog({ title: `Eliminar ${U.esc(c.nombre)}`, text: `Se eliminará el registro de ${c.year} con ${U.plural(c.visitas, 'visita', 'visitas')}, ${U.plural(c.informes, 'informe', 'informes')} y sus equipos.`, confirmLabel: 'Eliminar', danger: true });
      if (ok) { S.deleteClient(c.id); toast('Registro eliminado'); }
    }),
    'remove-marca': requireAdmin(el => { S.removeMarca(el.dataset.marca); F.adminPanel(); }),
    'regroup': requireAdmin(() => {
      const r = S.regroup();
      closeModal();
      toast(r.fusiones ? `${U.plural(r.fusiones, 'fusión realizada', 'fusiones realizadas')}` : 'No había duplicados que fusionar');
    }),
    'export': () => {
      const blob = new Blob([S.exportJSON()], { type: 'application/json' });
      const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: `registro-mantenimiento-${U.today()}.json` });
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      toast('Respaldo exportado');
    },
    'reset-demo': requireAdmin(async () => {
      const ok = await confirmDialog({ title: 'Cargar datos de ejemplo', text: 'Se reemplazarán los registros actuales. Exporta un respaldo si quieres conservarlos.', confirmLabel: 'Reemplazar', danger: true });
      if (ok) { S.loadDemo(); toast('Datos de ejemplo cargados'); }
    }),
    'clear-all': requireAdmin(async () => {
      const ok = await confirmDialog({ title: 'Borrar todo', text: 'Se eliminarán todos los registros de este navegador. Esta acción no se puede deshacer.', confirmLabel: 'Borrar todo', danger: true });
      if (ok) { S.clearAll(); toast('Datos borrados'); }
    }),
  };

  document.addEventListener('click', e => {
    const el = e.target.closest('[data-action]');
    if (el && actions[el.dataset.action]) actions[el.dataset.action](el);
  });

  S.init().then(() => {
    S.subscribe(render);
    setAdmin(MR.state.admin);
  });
})();
