/*
 * Capa de almacenamiento intercambiable.
 * Para usar una base de datos, registra otro adaptador con MR.storage.use({ load, save, subscribe }).
 * load() puede devolver los datos o una Promesa.
 */
window.MR = window.MR || {};

MR.storage = (() => {
  const key = MR.config.STORAGE_KEY;

  const localAdapter = {
    name: 'localStorage',
    load() {
      try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : null; }
      catch (err) { console.warn('No se pudo leer el almacenamiento local', err); return null; }
    },
    save(data) {
      try { localStorage.setItem(key, JSON.stringify(data)); return true; }
      catch (err) { console.error('No se pudo guardar', err); return false; }
    },
    subscribe(cb) {
      window.addEventListener('storage', e => {
        if (e.key === key && e.newValue) { try { cb(JSON.parse(e.newValue)); } catch { /* ignorar */ } }
      });
    },
  };

  let adapter = localAdapter;
  return {
    use(next) { adapter = next; },
    load: () => adapter.load(),
    save: d => adapter.save(d),
    subscribe: cb => adapter.subscribe && adapter.subscribe(cb),
  };
})();
