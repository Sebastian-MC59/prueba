# Registro de mantenimiento

Aplicación web para registrar visitas, informes y equipos de mantenimiento por cliente. Los registros se organizan en un contenedor por año (2026 y 2027). Los nombres se normalizan a su marca raíz, así no se crean clientes duplicados.

## Estructura

```
registro-mantenimiento/
├── index.html                      Página única: barra superior, panel, modal y avisos
├── css/styles.css                  Diseño, colores por año, modo oscuro y adaptación a tableta y móvil
├── js/
│   ├── config.js                   Años, PIN de administrador, marcas raíz, categorías y unidades
│   ├── utils.js                    Búsqueda sin tildes, resaltado, fechas y formato
│   ├── normalizer.js               Extracción de la marca raíz de un nombre
│   ├── storage.js                  Adaptador de almacenamiento (localStorage por defecto)
│   ├── seed.js                     Registros de ejemplo con variantes de nombre
│   ├── store.js                    Estado y reglas: unicidad, fusión, equipos, renombre
│   ├── ui.js                       Modal, confirmación, avisos y campos
│   ├── components/
│   │   └── equipment-field.js      Bloque Equipo: categoría, equipo específico y capacidad
│   ├── forms.js                    Nuevo registro, equipos, historial y administración
│   ├── views/dashboard.js          Panel con un contenedor por año
│   └── app.js                      Arranque, búsqueda, modo administrador y acciones
└── README.md
```

## Ejecutar localmente

**Sin instalar nada:** descomprime la carpeta y abre `index.html` con doble clic. La primera vez se cargan registros de ejemplo.

**Con un servidor local (recomendado al desarrollar):**

```bash
cd registro-mantenimiento
python -m http.server 8080     # abre http://localhost:8080
# o bien
npx serve .
```

En VS Code puedes usar la extensión Live Server: clic derecho en `index.html` → *Open with Live Server*.

**Publicar en GitHub Pages:** sube la carpeta a un repositorio con `index.html` en la raíz y activa *Settings → Pages → Deploy from a branch → main / (root)*.

## Cómo funciona

### Normalización y unicidad

Al guardar un registro, el nombre se convierte a mayúsculas, se le quitan las tildes y los signos, y se unen las siglas escritas con puntos. Luego se extrae la marca raíz:

| Nombre ingresado | Marca raíz |
|---|---|
| Cinemark Plaza Norte, CINEMARK centro, cinémark, Cine Mark | CINEMARK |
| C.C.I. Torre Sur, cci | CCI |
| Grupo GEA S.A., Gea Ingeniería y Servicios | GEA |
| A.I.E Ingeniería | AIE |
| Hotel Barceló Centro (marca no registrada) | BARCELO |

La raíz se obtiene en este orden:

1. Primero se buscan las marcas conocidas (`marcasRaiz` en `config.js`, ampliables desde Administración). Se aceptan escritas como palabra exacta, unidas a otra palabra (CINEMARKCR) o separadas (CINE MARK).
2. Si ninguna coincide, se toma la primera palabra significativa. Se ignoran términos genéricos como *Grupo*, *S.A.*, *Hotel*, *Centro* o *de*.

Un cliente es único por **año + marca raíz**. Si ya existe, el nuevo registro se fusiona con él:

- Se suman las visitas y los informes.
- El nombre ingresado se guarda como variante.
- El equipo se agrega. Si ya existía uno igual (misma categoría, equipo y capacidad), se suma su cantidad.

El formulario avisa mientras escribes si el registro se fusionará o creará un cliente nuevo.

### Contenedores por año

Cada año de `config.years` tiene su propio contenedor, con sus totales de clientes, visitas, informes y equipos. Un mismo cliente puede aparecer en ambos años con métricas independientes. Para añadir 2028 basta con agregarlo a la lista.

### Búsqueda en tiempo real

La barra superior filtra ambos años a la vez mientras escribes. Busca por:

- nombre visible,
- marca raíz,
- cualquier variante registrada,
- equipo específico, categoría o capacidad (por ejemplo, "120 TR").

No distingue tildes ni mayúsculas y resalta las coincidencias. Pulsa `Esc` para limpiarla.

### Equipo y capacidad

El bloque **Equipo** tiene la categoría y, en la misma fila, **Equipo específico** junto a **Capacidad** (valor numérico y unidad: TR, kW, BTU/h, HP, kVA, A, L, m³/h, CFM o unidades). La unidad se propone según la categoría.

La capacidad se guarda en el estado de cada equipo como `{ categoria, especifico, capacidad, unidad, cantidad }`. No se acepta una capacidad sin equipo específico. Puedes agregar equipos a un cliente existente desde *Agregar equipo*.

### Modo administrador

Pulsa *Modo administrador* e ingresa el PIN (inicial `1234`, se cambia en `config.js`). Al activarlo:

- Aparece un lápiz junto a cada nombre de cliente. Edítalo en línea; Enter guarda y Esc cancela. Si el nuevo nombre corresponde a una marca raíz que ya existe ese año, se ofrece fusionar ambos registros.
- Se habilitan la edición y eliminación de equipos y la eliminación de clientes.
- Se abre *Administración*, que permite:
  - gestionar las marcas raíz,
  - reagrupar los registros existentes con las marcas actuales,
  - exportar o importar respaldos en JSON,
  - cargar los datos de ejemplo o borrar todo.

El PIN solo evita cambios accidentales en el navegador; no es un control de seguridad. Si la app se usa en red con varios usuarios, valida el rol de administrador en el servidor.

## Modelo de datos

```js
{
  marcas: ['CINEMARK', 'CCI', 'AIE', 'GEA'],
  clients: [{
    id, year: 2026, root: 'CINEMARK', nombre: 'CINEMARK',
    variantes: ['Cinemark Plaza Norte', 'CINEMARK centro'],
    visitas: 6, informes: 4,
    equipos: [{ id, categoria: 'Climatización', especifico: 'Chiller', capacidad: 120, unidad: 'TR', cantidad: 2 }],
    historial: [{ fecha: '2026-10-16', tipo: 'alta' | 'fusion' | 'edicion' | 'equipo', detalle }],
    creado, actualizado,
  }],
}
```

## Conectar una base de datos

Toda la persistencia pasa por `MR.storage`. Para usar una API, carga un archivo después de `storage.js` con un adaptador:

```js
MR.storage.use({
  async load() {
    const r = await fetch('/api/mantenimiento');
    return r.ok ? r.json() : null;
  },
  save(data) {
    fetch('/api/mantenimiento', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
    return true;
  },
});
```

En una base relacional conviene crear una restricción única sobre `(year, root)`. Así el servidor también impide duplicados, aunque dos personas registren el mismo cliente a la vez.
