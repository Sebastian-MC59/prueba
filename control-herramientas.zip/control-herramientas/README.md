# Bodega de herramientas

Aplicación web para controlar el inventario, los préstamos y el mantenimiento de herramientas. Funciona en escritorio y tableta, no necesita instalación ni compilación y guarda los datos en el navegador mediante una capa de almacenamiento que puede cambiarse por una base de datos.

## Estructura del proyecto

```
control-herramientas/
├── index.html              Página única: menú, barra superior, contenedores de vista y modal
├── css/
│   └── styles.css          Diseño completo, modo claro/oscuro y adaptación a tableta y móvil
├── js/
│   ├── config.js           Catálogos editables: categorías, estados, ubicaciones, plazos
│   ├── utils.js            Fechas locales, búsqueda sin tildes, formato y escape de HTML
│   ├── storage.js          Adaptador de almacenamiento (localStorage por defecto)
│   ├── seed.js             Datos de ejemplo con fechas relativas a hoy
│   ├── store.js            Estado central y reglas de negocio (préstamos, devoluciones, mantenimiento)
│   ├── ui.js               Componentes: modal, confirmación, avisos, etiquetas de estado
│   ├── forms.js            Formularios: alta/edición, salida, devolución, mantenimiento y ficha con historial
│   ├── app.js              Arranque, enrutador por hash, búsqueda global y acciones
│   └── views/
│       ├── dashboard.js    Panel de control con métricas y alertas
│       ├── inventory.js    Inventario con filtros combinables
│       ├── loans.js        Préstamos activos, atrasados y devueltos
│       └── maintenance.js  Mantenimiento en curso, preventivos e historial
└── README.md
```

Cada capa tiene una sola responsabilidad: las vistas solo leen del `store` y llaman a sus acciones; el `store` valida, guarda mediante `storage` y avisa a las vistas para que se redibujen.

## Puesta en marcha

### Opción 1: abrir directamente

Descomprime la carpeta y abre `index.html` con doble clic en Chrome, Edge, Firefox o Safari. La primera vez se cargan datos de ejemplo para que puedas probar todo.

### Opción 2: servidor local (recomendado para desarrollo)

Desde la carpeta del proyecto, ejecuta cualquiera de estos comandos y abre la dirección que indique:

```bash
python -m http.server 8080      # luego visita http://localhost:8080
npx serve .                     # alternativa con Node.js
```

En VS Code también sirve la extensión **Live Server** (clic derecho en `index.html` → *Open with Live Server*).

### Opción 3: publicar en GitHub Pages

1. Crea un repositorio en GitHub y sube el contenido de la carpeta (con `index.html` en la raíz):
   ```bash
   git init
   git add .
   git commit -m "Control de herramientas"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/control-herramientas.git
   git push -u origin main
   ```
2. En el repositorio entra a **Settings → Pages**.
3. En *Build and deployment* elige **Deploy from a branch**, rama `main` y carpeta `/ (root)`. Guarda.
4. En uno o dos minutos la app estará en `https://TU_USUARIO.github.io/control-herramientas/`.

Recuerda que con `localStorage` cada navegador guarda sus propios datos. Para compartir información entre varios equipos, conecta una base de datos (ver más abajo).

## Uso

**Panel.** Muestra el total de herramientas, cuántas están disponibles, prestadas, en mantenimiento y las devoluciones atrasadas. Cada tarjeta y cada tramo de la barra de estado abre el inventario ya filtrado. Debajo aparecen los préstamos vencidos, los preventivos próximos, el reparto por categoría y la actividad reciente.

**Búsqueda en tiempo real.** La barra superior filtra mientras escribes por código, nombre, categoría, marca, ubicación u operario responsable, sin importar tildes ni mayúsculas. Se adapta a la sección abierta: en Préstamos busca por operario o destino y en Mantenimiento por técnico o descripción. Pulsa `/` para enfocarla y `Esc` para limpiarla.

**Inventario.** Combina filtros de categoría, estado, ubicación y orden, o marca *Solo con devolución atrasada*. Las filas con préstamo vencido se destacan en rojo. Toca una fila para abrir la ficha con su historial completo.

**Registrar salida (check-out).** Escribe o escanea el código (los lectores de código de barras USB funcionan como teclado), indica el operario asignado y quién la retira o autoriza, y elige la devolución con los atajos de 1 a 30 días. Si indicas un destino, la ubicación de la herramienta cambia a ese proyecto u obra.

**Registrar devolución (check-in).** Indica la fecha, a dónde vuelve y su condición. Si vuelve con falla, se abre automáticamente una reparación en curso y la herramienta pasa a *En mantenimiento*.

**Mantenimiento.** Registra trabajos ya hechos (quedan en el historial) o envía una herramienta al taller (queda en mantenimiento hasta que lo finalices). Al finalizar decides si vuelve a servicio o se retira. La fecha de próximo mantenimiento genera avisos con 15 días de anticipación.

**Respaldo de datos.** Desde el menú lateral puedes exportar todo a un archivo JSON, importarlo en otro equipo, cargar los datos de ejemplo o borrar todo.

### Reglas que aplica la app

Una herramienta solo se presta si está *Disponible* y su código es único. No puede cambiarse manualmente a *En uso* (se hace registrando una salida) ni salir de ese estado sin registrar la devolución. No se puede eliminar una herramienta prestada; si dejó de usarse, conviene marcarla como *Retirada* para conservar su historial. Las fechas de devolución no pueden ser anteriores a la salida.

## Personalización

Edita `js/config.js` para cambiar las categorías, ubicaciones, tipos de mantenimiento, el plazo de préstamo sugerido y los días de aviso de mantenimiento. Los colores y tipografías están como variables al inicio de `css/styles.css`.

## Modelo de datos

```js
// Herramienta
{ id, sku, nombre, categoria, estado: 'disponible' | 'en_uso' | 'mantenimiento' | 'retirada',
  ubicacionTipo, ubicacionDetalle, marca, modelo, numeroSerie, proximoMantenimiento, notas, creado, actualizado }

// Préstamo
{ id, toolId, asignadoA, retiradoPor, fechaSalida, fechaDevolucionEstimada, fechaDevolucionReal,
  destino, notasSalida, ubicacionOrigen: { tipo, detalle }, condicionDevolucion: 'buena' | 'mantenimiento', notasDevolucion }

// Mantenimiento
{ id, toolId, tipo, estado: 'en_curso' | 'completado', fecha, fechaFin, descripcion, tecnico, costo, proximaFecha,
  resultado: 'disponible' | 'retirada' }
```

Las fechas se guardan como texto `AAAA-MM-DD` en hora local, lo que facilita compararlas y llevarlas a una base de datos.

## Conectar una base de datos

Toda la persistencia pasa por `TM.storage`. Para usar un servidor propio, registra un adaptador antes de `app.js` (por ejemplo en un archivo `js/api-adapter.js` incluido justo después de `storage.js`):

```js
TM.storage.use({
  name: 'api',
  async load() {
    const res = await fetch('https://tu-servidor.com/api/herramientas');
    return res.ok ? res.json() : null;           // { tools: [], loans: [], maintenance: [] }
  },
  save(data) {
    fetch('https://tu-servidor.com/api/herramientas', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }).catch(err => console.error('No se pudo sincronizar', err));
    return true;
  },
  subscribe(callback) {
    // Opcional: sondeo o WebSocket para ver cambios de otros usuarios
    setInterval(async () => callback(await this.load()), 15000);
  },
});
```

Este enfoque guarda el documento completo, ideal para equipos pequeños. Para muchos usuarios simultáneos conviene un endpoint por acción (`POST /prestamos`, `PATCH /prestamos/:id/devolucion`, etc.): cada función de `store.js` (`checkout`, `checkin`, `addMaintenance`…) ya agrupa una operación completa, así que basta con añadir ahí la llamada correspondiente. Servicios como Supabase, Firebase o una API con Node.js y PostgreSQL encajan con el modelo de datos anterior sin cambios.

## Compatibilidad

Navegadores actuales (Chrome, Edge, Firefox y Safari de los últimos dos años). Las fuentes se cargan desde Google Fonts; sin conexión se usa la tipografía del sistema y todo sigue funcionando.
