/* Configuración y catálogos editables de la aplicación. */
window.TM = window.TM || {};

TM.config = {
  STORAGE_KEY: 'bodega.herramientas.v1',

  categorias: ['Eléctrica', 'Manual', 'Medición', 'Neumática', 'Corte', 'Seguridad', 'Otra'],

  // tone se usa para el color de la etiqueta de estado
  estados: {
    disponible:    { label: 'Disponible',       tone: 'ok' },
    en_uso:        { label: 'En uso',           tone: 'info' },
    mantenimiento: { label: 'En mantenimiento', tone: 'warn' },
    retirada:      { label: 'Retirada',         tone: 'muted' },
  },

  ubicaciones: ['Almacén', 'Caja de herramientas', 'Proyecto / obra', 'Taller'],

  tiposMantenimiento: ['Preventivo', 'Reparación', 'Calibración', 'Inspección'],

  diasPrestamoPorDefecto: 7,   // devolución sugerida al registrar una salida
  diasAvisoMantenimiento: 15,  // cuántos días antes avisar del próximo mantenimiento
  atajosPrestamo: [1, 3, 7, 15, 30],
};
