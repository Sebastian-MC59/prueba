/* Datos de ejemplo con fechas relativas a hoy, para probar la app desde el primer momento. */
window.TM = window.TM || {};

TM.seed = function seed() {
  const { uid, today, addDays } = TM.utils;
  const t = today();

  const tool = (sku, nombre, categoria, marca, ubicacionTipo, ubicacionDetalle, estado = 'disponible', proximo = null) => ({
    id: uid('t'), sku, nombre, categoria, marca, modelo: '', numeroSerie: '',
    ubicacionTipo, ubicacionDetalle, estado, proximoMantenimiento: proximo,
    notas: '', creado: addDays(t, -180), actualizado: t,
  });

  const tools = [
    tool('ELE-001', 'Taladro percutor 20 V', 'Eléctrica', 'DeWalt', 'Proyecto / obra', 'Obra Torre Norte', 'en_uso', addDays(t, 40)),
    tool('ELE-002', 'Esmeriladora angular 4½"', 'Eléctrica', 'Makita', 'Proyecto / obra', 'Obra Residencial Los Pinos', 'en_uso', addDays(t, 9)),
    tool('ELE-003', 'Sierra circular 7¼"', 'Eléctrica', 'Bosch', 'Taller', 'Banco 1', 'mantenimiento'),
    tool('ELE-004', 'Rotomartillo SDS Plus', 'Eléctrica', 'Hilti', 'Almacén', 'Estante A3', 'disponible', addDays(t, -3)),
    tool('MAN-001', 'Juego de llaves combinadas 12 piezas', 'Manual', 'Stanley', 'Caja de herramientas', 'Caja 04'),
    tool('MAN-002', 'Llave de torque ½"', 'Manual', 'Truper', 'Proyecto / obra', 'Obra Torre Norte', 'en_uso', addDays(t, 120)),
    tool('MAN-003', 'Juego de destornilladores aislados', 'Manual', 'Klein Tools', 'Caja de herramientas', 'Caja 02'),
    tool('MAN-004', 'Mazo de goma', 'Manual', 'Truper', 'Almacén', 'Estante C1', 'retirada'),
    tool('MED-001', 'Multímetro digital', 'Medición', 'Fluke', 'Almacén', 'Gaveta M1', 'disponible', addDays(t, 6)),
    tool('MED-002', 'Nivel láser de líneas', 'Medición', 'Bosch', 'Proyecto / obra', 'Obra Residencial Los Pinos', 'en_uso', addDays(t, 60)),
    tool('MED-003', 'Cinta métrica 8 m', 'Medición', 'Stanley', 'Caja de herramientas', 'Caja 04'),
    tool('MED-004', 'Pie de rey digital', 'Medición', 'Mitutoyo', 'Almacén', 'Gaveta M2', 'disponible', addDays(t, 25)),
    tool('NEU-001', 'Compresor 50 L', 'Neumática', 'Campbell', 'Taller', 'Zona de compresores', 'disponible', addDays(t, 90)),
    tool('SEG-001', 'Arnés de seguridad', 'Seguridad', '3M', 'Almacén', 'Estante S1', 'disponible', addDays(t, 4)),
    tool('COR-001', 'Cortadora de azulejo', 'Corte', 'Rubi', 'Almacén', 'Estante B4'),
  ];
  const id = sku => tools.find(x => x.sku === sku).id;

  const loan = (sku, asignadoA, retiradoPor, salida, estimada, real = null, extra = {}) => ({
    id: uid('p'), toolId: id(sku), asignadoA, retiradoPor,
    fechaSalida: addDays(t, salida), fechaDevolucionEstimada: addDays(t, estimada),
    fechaDevolucionReal: real === null ? null : addDays(t, real),
    destino: '', notasSalida: '', condicionDevolucion: real === null ? null : 'buena', notasDevolucion: '',
    ubicacionOrigen: { tipo: 'Almacén', detalle: '' }, ...extra,
  });

  const loans = [
    // Activos
    loan('ELE-001', 'Carlos Méndez', 'Laura Jiménez', -5, 2, null, { destino: 'Obra Torre Norte', ubicacionOrigen: { tipo: 'Almacén', detalle: 'Estante A2' } }),
    loan('ELE-002', 'Ana Rojas', 'Laura Jiménez', -12, -4, null, { destino: 'Obra Residencial Los Pinos', ubicacionOrigen: { tipo: 'Almacén', detalle: 'Estante A1' } }),
    loan('MAN-002', 'Luis Vargas', 'Pedro Castro', -9, -1, null, { destino: 'Obra Torre Norte', ubicacionOrigen: { tipo: 'Almacén', detalle: 'Gaveta B1' } }),
    loan('MED-002', 'María Solís', 'Pedro Castro', -3, 10, null, { destino: 'Obra Residencial Los Pinos', ubicacionOrigen: { tipo: 'Almacén', detalle: 'Gaveta M3' } }),
    // Historial cerrado
    loan('ELE-004', 'Carlos Méndez', 'Laura Jiménez', -30, -23, -22),
    loan('MED-001', 'Ana Rojas', 'Pedro Castro', -26, -19, -20),
    loan('ELE-003', 'Jorge Araya', 'Laura Jiménez', -16, -9, -3, { condicionDevolucion: 'mantenimiento', notasDevolucion: 'Hace ruido al arrancar' }),
    loan('NEU-001', 'Luis Vargas', 'Pedro Castro', -45, -40, -40),
    loan('MAN-001', 'María Solís', 'Laura Jiménez', -14, -10, -11),
  ];

  const maint = (sku, tipo, fecha, descripcion, tecnico, costo, extra = {}) => ({
    id: uid('m'), toolId: id(sku), tipo, estado: 'completado', fecha: addDays(t, fecha), fechaFin: addDays(t, fecha),
    descripcion, tecnico, costo, proximaFecha: null, resultado: 'disponible', ...extra,
  });

  const maintenance = [
    maint('ELE-003', 'Reparación', -3, 'Hace ruido al arrancar. Revisión de carbones y rodamientos', 'Taller interno', null, { estado: 'en_curso', fechaFin: null, resultado: null }),
    maint('MED-001', 'Calibración', -174, 'Calibración anual con certificado', 'Metrología Central', 85000, { proximaFecha: addDays(t, 6) }),
    maint('ELE-004', 'Preventivo', -95, 'Limpieza, engrase y revisión del cable', 'Taller interno', 12000, { proximaFecha: addDays(t, -3) }),
    maint('NEU-001', 'Preventivo', -30, 'Drenaje del tanque y cambio de filtro de aire', 'Taller interno', 18500, { proximaFecha: addDays(t, 90) }),
    maint('MAN-004', 'Inspección', -20, 'Mango fracturado. Se retira de servicio', 'Laura Jiménez', null, { resultado: 'retirada' }),
    maint('SEG-001', 'Inspección', -176, 'Inspección semestral de costuras y hebillas', 'Seguridad ocupacional', null, { proximaFecha: addDays(t, 4) }),
  ];

  return { version: 1, tools, loans, maintenance };
};
