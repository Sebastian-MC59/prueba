/* Formularios y fichas en modal. Se usan desde cualquier vista mediante data-action. */
window.TM = window.TM || {};

TM.forms = (() => {
  const U = TM.utils;
  const C = TM.config;
  const S = TM.store;
  const { field, options, openModal, closeModal, toast, confirmDialog, stateBadge, skuTag, dueBadge, icon } = TM.ui;
  const esc = U.esc;

  /* Selector de herramienta por código: admite teclear o escanear un código de barras */
  function toolPicker({ selected, allow, autofocus }) {
    const list = S.tools().filter(allow).sort(U.bySku);
    return `
      <input name="sku" required autocomplete="off" spellcheck="false" list="tool-options" class="input-sku"
        placeholder="Escribe o escanea el código" value="${esc(selected?.sku || '')}" ${autofocus ? 'autofocus' : ''} data-tool-picker>
      <datalist id="tool-options">${list.map(t => `<option value="${esc(t.sku)}">${esc(t.nombre)}</option>`).join('')}</datalist>
      <span class="picker-preview" aria-live="polite"></span>`;
  }

  function bindPicker(modal, allow, reason) {
    const input = modal.querySelector('[data-tool-picker]');
    const preview = modal.querySelector('.picker-preview');
    const update = () => {
      const value = input.value.trim();
      const t = S.toolBySku(value);
      if (!value) preview.innerHTML = '';
      else if (!t) preview.innerHTML = '<span class="text-muted">No hay ninguna herramienta con ese código</span>';
      else if (!allow(t)) preview.innerHTML = `<span class="text-danger">${esc(t.nombre)}: ${reason(t)}</span>`;
      else preview.innerHTML = `${stateBadge(t.estado)}<span>${esc(t.nombre)}</span>`;
    };
    input.addEventListener('input', update);
    update();
  }

  const resolveTool = sku => S.toolBySku(sku) || (() => { throw new Error(`No existe una herramienta con el código ${String(sku).toUpperCase()}.`); })();

  /* ---------- Alta y edición ---------- */
  function toolForm(id) {
    const t = id ? S.tool(id) : null;
    const prestada = t?.estado === 'en_uso';
    const estados = Object.entries(C.estados)
      .filter(([k]) => k !== 'en_uso' || prestada)
      .map(([k, v]) => [k, v.label]);

    const body = `<div class="grid-2">
      ${field('Código / SKU', `<input name="sku" required maxlength="30" class="input-sku" value="${esc(t?.sku || '')}" placeholder="ELE-005" autocomplete="off" autofocus>`, { hint: 'Único por herramienta. Puede ser el código de su etiqueta.' })}
      ${field('Nombre de la herramienta', `<input name="nombre" required maxlength="80" value="${esc(t?.nombre || '')}" placeholder="Taladro percutor 20 V">`)}
      ${field('Categoría', `<select name="categoria">${options(C.categorias, t?.categoria)}</select>`)}
      ${field('Estado', prestada
        ? `<select disabled>${options(estados, 'en_uso')}</select><input type="hidden" name="estado" value="en_uso">`
        : `<select name="estado">${options(estados, t?.estado || 'disponible')}</select>`,
        prestada ? { hint: 'Está prestada. El estado cambia al registrar la devolución.' } : {})}
      ${field('Ubicación física', `<select name="ubicacionTipo">${options(C.ubicaciones, t?.ubicacionTipo)}</select>`)}
      ${field('Detalle de ubicación', `<input name="ubicacionDetalle" maxlength="60" value="${esc(t?.ubicacionDetalle || '')}" placeholder="Estante A2, Caja 04, Obra Torre Norte">`)}
      ${field('Marca', `<input name="marca" maxlength="40" value="${esc(t?.marca || '')}">`)}
      ${field('Modelo', `<input name="modelo" maxlength="40" value="${esc(t?.modelo || '')}">`)}
      ${field('Número de serie', `<input name="numeroSerie" maxlength="40" value="${esc(t?.numeroSerie || '')}">`)}
      ${field('Próximo mantenimiento', `<input type="date" name="proximoMantenimiento" value="${esc(t?.proximoMantenimiento || '')}">`, { hint: 'Opcional. Genera un aviso cuando se acerque.' })}
      ${field('Notas', `<textarea name="notas" rows="2" maxlength="300">${esc(t?.notas || '')}</textarea>`, { full: true })}
    </div>`;

    openModal({
      title: t ? `Editar ${esc(t.sku)}` : 'Nueva herramienta',
      body, size: 'lg',
      submitLabel: t ? 'Guardar cambios' : 'Registrar herramienta',
      onSubmit: values => {
        const saved = S.saveTool({ ...values, id: t?.id });
        toast(t ? 'Cambios guardados' : `${saved.sku} registrada en el inventario`);
      },
    });
  }

  async function deleteTool(id) {
    const t = S.tool(id);
    if (!t) return;
    if (S.activeLoanFor(id)) return toast('Registra la devolución antes de eliminarla.', 'danger');
    const ok = await confirmDialog({
      title: `Eliminar ${esc(t.sku)}`,
      text: `Se eliminará <strong>${esc(t.nombre)}</strong> junto con su historial de préstamos y mantenimientos. Si solo dejó de usarse, márcala como <em>Retirada</em> para conservar el historial.`,
      confirmLabel: 'Eliminar definitivamente', danger: true,
    });
    if (ok) { S.deleteTool(id); toast(`${t.sku} eliminada`); }
  }

  /* ---------- Salida (check-out) ---------- */
  function checkoutForm(toolId) {
    const preset = toolId ? S.tool(toolId) : null;
    if (preset && preset.estado !== 'disponible') return toast(`${preset.sku} no está disponible para préstamo.`, 'warn');
    if (!S.tools().some(t => t.estado === 'disponible')) return toast('No hay herramientas disponibles para prestar.', 'warn');

    const hoy = U.today();
    const allow = t => t.estado === 'disponible';
    const body = `
      ${field('Herramienta', toolPicker({ selected: preset, allow, autofocus: !preset }), { full: true })}
      <div class="grid-2">
        ${field('Asignada a (operario)', `<input name="asignadoA" required list="people" autocomplete="off" maxlength="60" ${preset ? 'autofocus' : ''}>`)}
        ${field('Retirada por / autoriza', `<input name="retiradoPor" required list="people" autocomplete="off" maxlength="60">`)}
        ${field('Fecha de salida', `<input type="date" name="fechaSalida" required value="${hoy}">`)}
        ${field('Devolución estimada', `<input type="date" name="fechaDevolucionEstimada" required min="${hoy}" value="${U.addDays(hoy, C.diasPrestamoPorDefecto)}">`)}
      </div>
      <div class="quick-days" role="group" aria-label="Plazo rápido">
        <span class="text-muted">Plazo:</span>
        ${C.atajosPrestamo.map(d => `<button type="button" class="chip" data-days="${d}">${U.plural(d, 'día', 'días')}</button>`).join('')}
      </div>
      <div class="grid-2">
        ${field('Destino (proyecto u obra)', `<input name="destino" maxlength="60" placeholder="Opcional. Actualiza la ubicación">`)}
        ${field('Notas de salida', `<input name="notasSalida" maxlength="200" placeholder="Accesorios, estado al salir">`)}
      </div>
      <datalist id="people">${S.people().map(p => `<option value="${esc(p)}">`).join('')}</datalist>`;

    const modal = openModal({
      title: 'Registrar salida', subtitle: 'Préstamo de una herramienta disponible',
      body, size: 'lg', submitLabel: 'Registrar salida',
      onSubmit: values => {
        const t = resolveTool(values.sku);
        S.checkout({ ...values, toolId: t.id });
        toast(`${t.sku} asignada a ${values.asignadoA.trim()}`);
      },
    });
    bindPicker(modal, allow, t => C.estados[t.estado].label.toLowerCase());

    const salida = modal.querySelector('[name=fechaSalida]');
    const estimada = modal.querySelector('[name=fechaDevolucionEstimada]');
    salida.addEventListener('change', () => { estimada.min = salida.value; });
    modal.querySelectorAll('[data-days]').forEach(b => b.addEventListener('click', () => {
      estimada.value = U.addDays(salida.value || hoy, Number(b.dataset.days));
    }));
  }

  /* ---------- Devolución (check-in) ---------- */
  function checkinForm(loanId) {
    const l = S.loan(loanId);
    if (!l || l.fechaDevolucionReal) return toast('No hay un préstamo activo para esta herramienta.', 'warn');
    const t = S.tool(l.toolId);
    const hoy = U.today();
    const origen = l.ubicacionOrigen || { tipo: 'Almacén', detalle: '' };

    const body = `
      <div class="summary-card">
        <div class="summary-top">${skuTag(t.sku)}<strong>${esc(t.nombre)}</strong></div>
        <dl class="facts">
          <div><dt>Asignada a</dt><dd>${esc(l.asignadoA)}</dd></div>
          <div><dt>Salida</dt><dd>${U.fmtDate(l.fechaSalida)}</dd></div>
          <div><dt>Devolución estimada</dt><dd>${U.fmtDate(l.fechaDevolucionEstimada)}</dd></div>
          <div><dt>Plazo</dt><dd>${dueBadge(l)}</dd></div>
        </dl>
      </div>
      <fieldset class="choices">
        <legend>¿En qué condición vuelve?</legend>
        <label class="choice"><input type="radio" name="condicion" value="buena" checked><span><strong>En buen estado</strong><small>Queda disponible para un nuevo préstamo</small></span></label>
        <label class="choice"><input type="radio" name="condicion" value="mantenimiento"><span><strong>Requiere mantenimiento</strong><small>Se abre una reparación en curso</small></span></label>
      </fieldset>
      <div class="grid-2">
        ${field('Fecha de devolución', `<input type="date" name="fechaDevolucionReal" required min="${l.fechaSalida}" value="${hoy}">`)}
        ${field('Vuelve a', `<select name="ubicacionTipo">${options(C.ubicaciones, origen.tipo)}</select>`)}
        ${field('Detalle de ubicación', `<input name="ubicacionDetalle" maxlength="60" value="${esc(origen.detalle || '')}">`)}
        ${field('Observaciones', `<input name="notasDevolucion" maxlength="200" placeholder="Falla, accesorio faltante, desgaste">`)}
      </div>`;

    openModal({
      title: 'Registrar devolución', body, size: 'lg', submitLabel: 'Registrar devolución',
      onSubmit: values => {
        if (values.condicion === 'mantenimiento' && !values.notasDevolucion.trim()) {
          throw new Error('Describe la falla en Observaciones para abrir la reparación.');
        }
        S.checkin(l.id, values);
        toast(values.condicion === 'mantenimiento' ? `${t.sku} enviada a mantenimiento` : `${t.sku} devuelta y disponible`);
      },
    });
  }

  /* ---------- Mantenimiento ---------- */
  function maintenanceForm(toolId) {
    const preset = toolId ? S.tool(toolId) : null;
    if (!S.tools().length) return toast('Registra primero una herramienta.', 'warn');
    const allow = t => t.estado !== 'retirada';
    const hoy = U.today();

    const body = `
      ${field('Herramienta', toolPicker({ selected: preset, allow, autofocus: !preset }), { full: true })}
      <fieldset class="choices">
        <legend>¿Qué quieres registrar?</legend>
        <label class="choice"><input type="radio" name="modalidad" value="completado" checked><span><strong>Trabajo ya realizado</strong><small>Se anota en el historial y la herramienta conserva su estado</small></span></label>
        <label class="choice"><input type="radio" name="modalidad" value="en_curso"><span><strong>Enviar a mantenimiento ahora</strong><small>Queda en mantenimiento hasta que lo finalices</small></span></label>
      </fieldset>
      <div class="grid-2">
        ${field('Tipo', `<select name="tipo" ${preset ? 'autofocus' : ''}>${options(C.tiposMantenimiento)}</select>`)}
        ${field('Fecha', `<input type="date" name="fecha" required value="${hoy}">`)}
        ${field('Técnico o proveedor', `<input name="tecnico" maxlength="60">`)}
        ${field('Costo', `<input type="number" name="costo" min="0" step="0.01" inputmode="decimal" placeholder="Opcional">`)}
        ${field('Descripción del trabajo o la falla', `<textarea name="descripcion" rows="2" required maxlength="300"></textarea>`, { full: true })}
        ${field('Próximo mantenimiento preventivo', `<input type="date" name="proximaFecha">`, { hint: 'Opcional. Programa el siguiente aviso.' })}
      </div>`;

    const modal = openModal({
      title: 'Registrar mantenimiento', body, size: 'lg', submitLabel: 'Guardar registro',
      onSubmit: values => {
        const t = resolveTool(values.sku);
        if (!allow(t)) throw new Error(`${t.sku} está retirada de servicio.`);
        S.addMaintenance({ ...values, toolId: t.id });
        toast(values.modalidad === 'en_curso' ? `${t.sku} en mantenimiento` : `Mantenimiento de ${t.sku} registrado`);
      },
    });
    bindPicker(modal, allow, () => 'retirada de servicio');
  }

  function completeMaintenanceForm(maintId) {
    const m = S.maintenance().find(x => x.id === maintId);
    if (!m || m.estado !== 'en_curso') return;
    const t = S.tool(m.toolId);
    const body = `
      <div class="summary-card">
        <div class="summary-top">${skuTag(t.sku)}<strong>${esc(t.nombre)}</strong></div>
        <p class="text-muted">${esc(m.tipo)} desde ${U.fmtDate(m.fecha)}. ${esc(m.descripcion)}</p>
      </div>
      <fieldset class="choices">
        <legend>Resultado</legend>
        <label class="choice"><input type="radio" name="resultado" value="disponible" checked><span><strong>Vuelve a servicio</strong><small>Queda disponible</small></span></label>
        <label class="choice"><input type="radio" name="resultado" value="retirada"><span><strong>Retirar de servicio</strong><small>No tiene reparación o no conviene repararla</small></span></label>
      </fieldset>
      <div class="grid-2">
        ${field('Fecha de finalización', `<input type="date" name="fechaFin" required min="${m.fecha}" value="${U.today()}" autofocus>`)}
        ${field('Costo', `<input type="number" name="costo" min="0" step="0.01" inputmode="decimal" value="${m.costo ?? ''}">`)}
        ${field('Técnico o proveedor', `<input name="tecnico" maxlength="60" value="${esc(m.tecnico || '')}">`)}
        ${field('Próximo mantenimiento preventivo', `<input type="date" name="proximaFecha" value="${esc(t.proximoMantenimiento && t.proximoMantenimiento > U.today() ? t.proximoMantenimiento : '')}">`)}
        ${field('Trabajo realizado', `<textarea name="notas" rows="2" maxlength="300" placeholder="Piezas cambiadas, ajustes, observaciones"></textarea>`, { full: true })}
      </div>`;
    openModal({
      title: 'Finalizar mantenimiento', body, size: 'lg', submitLabel: 'Finalizar mantenimiento',
      onSubmit: values => {
        S.completeMaintenance(m.id, values);
        toast(values.resultado === 'retirada' ? `${t.sku} retirada de servicio` : `${t.sku} disponible de nuevo`);
      },
    });
  }

  /* ---------- Ficha con historial ---------- */
  function toolDetail(id) {
    const t = S.tool(id);
    if (!t) return;
    const l = S.activeLoanFor(id);
    const om = S.openMaintenanceFor(id);
    const events = S.history(id);
    const prestamos = S.loans().filter(x => x.toolId === id).length;
    const costoTotal = S.maintenance().filter(m => m.toolId === id && m.costo).reduce((a, m) => a + m.costo, 0);

    const primary = t.estado === 'disponible'
      ? `<button type="button" class="btn btn-primary" data-action="checkout" data-id="${t.id}">${icon('out')}Registrar salida</button>`
      : l ? `<button type="button" class="btn btn-primary" data-action="checkin" data-loan="${l.id}">${icon('in')}Registrar devolución</button>`
      : om ? `<button type="button" class="btn btn-primary" data-action="complete-maint" data-id="${om.id}">Finalizar mantenimiento</button>` : '';

    const body = `
      <div class="detail-head">
        <div class="detail-title">${skuTag(t.sku)}${stateBadge(t.estado)}</div>
        <p class="detail-name">${esc(t.nombre)}</p>
      </div>
      ${l ? `<div class="callout ${S.isOverdue(l) ? 'tone-danger' : 'tone-info'}">
        <strong>Prestada a ${esc(l.asignadoA)}</strong> desde ${U.fmtDate(l.fechaSalida)}. Devolución prevista ${U.fmtDate(l.fechaDevolucionEstimada)}. ${dueBadge(l)}
      </div>` : ''}
      <dl class="facts facts-wide">
        <div><dt>Categoría</dt><dd>${esc(t.categoria)}</dd></div>
        <div><dt>Ubicación</dt><dd>${esc(t.ubicacionTipo)}${t.ubicacionDetalle ? `<br><span class="text-muted">${esc(t.ubicacionDetalle)}</span>` : ''}</dd></div>
        <div><dt>Marca y modelo</dt><dd>${esc([t.marca, t.modelo].filter(Boolean).join(' ') || '—')}</dd></div>
        <div><dt>Número de serie</dt><dd>${esc(t.numeroSerie || '—')}</dd></div>
        <div><dt>Próximo mantenimiento</dt><dd>${U.fmtDate(t.proximoMantenimiento)}</dd></div>
        <div><dt>Uso y costo</dt><dd>${U.plural(prestamos, 'préstamo', 'préstamos')}<br><span class="text-muted">${costoTotal ? `${U.money(costoTotal)} en mantenimiento` : 'Sin costos registrados'}</span></dd></div>
      </dl>
      ${t.notas ? `<p class="notes">${esc(t.notas)}</p>` : ''}
      <div class="detail-actions">
        ${primary}
        ${t.estado !== 'retirada' ? `<button type="button" class="btn btn-secondary" data-action="maintenance" data-id="${t.id}">${icon('gear')}Registrar mantenimiento</button>` : ''}
        <button type="button" class="btn btn-ghost" data-action="edit-tool" data-id="${t.id}">${icon('edit')}Editar</button>
        <button type="button" class="btn btn-ghost danger-text" data-action="delete-tool" data-id="${t.id}">${icon('trash')}Eliminar</button>
      </div>
      <h3 class="section-title">Historial</h3>
      <ol class="timeline">
        ${events.map(e => `<li class="ev ev-${e.tipo}">
          <span class="ev-date">${U.fmtDate(e.fecha)}</span>
          <div><strong>${esc(e.titulo)}</strong>${e.detalle ? `<p>${esc(e.detalle)}</p>` : ''}</div>
        </li>`).join('')}
      </ol>`;

    openModal({
      title: 'Ficha de herramienta', body, size: 'lg',
      footer: '<button type="button" class="btn btn-ghost" data-close>Cerrar</button>',
    });
  }

  return { toolForm, deleteTool, checkoutForm, checkinForm, maintenanceForm, completeMaintenanceForm, toolDetail, close: closeModal };
})();
