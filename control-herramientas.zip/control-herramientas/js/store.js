/*
 * Estado central y reglas de negocio.
 * Las vistas solo leen con las consultas y modifican con las acciones de este módulo.
 * Cada acción valida, guarda y notifica a los suscriptores (las vistas se redibujan).
 */
window.TM = window.TM || {};

TM.store = (() => {
  const U = TM.utils;
  const C = TM.config;
  let data = { version: 1, tools: [], loans: [], maintenance: [] };
  const listeners = new Set();

  const normalize = d => ({
    version: 1,
    tools: Array.isArray(d?.tools) ? d.tools : [],
    loans: Array.isArray(d?.loans) ? d.loans : [],
    maintenance: Array.isArray(d?.maintenance) ? d.maintenance : [],
  });
  const emit = () => listeners.forEach(fn => fn());
  const commit = () => { TM.storage.save(data); emit(); };
  const fail = message => { throw new Error(message); };
  const text = v => String(v ?? '').trim();

  async function init() {
    const loaded = await TM.storage.load();
    data = loaded ? normalize(loaded) : TM.seed();
    if (!loaded) TM.storage.save(data);
    TM.storage.subscribe(next => { data = normalize(next); emit(); });
  }
  const subscribe = fn => { listeners.add(fn); return () => listeners.delete(fn); };

  /* ---------- Consultas ---------- */
  const tools = () => data.tools;
  const tool = id => data.tools.find(t => t.id === id);
  const toolBySku = sku => data.tools.find(t => t.sku === text(sku).toUpperCase());
  const loans = () => data.loans;
  const loan = id => data.loans.find(l => l.id === id);
  const activeLoans = () => data.loans.filter(l => !l.fechaDevolucionReal);
  const activeLoanFor = toolId => data.loans.find(l => l.toolId === toolId && !l.fechaDevolucionReal);
  const isOverdue = l => !l.fechaDevolucionReal && l.fechaDevolucionEstimada < U.today();
  const overdueLoans = () => activeLoans().filter(isOverdue);
  const maintenance = () => data.maintenance;
  const openMaintenance = () => data.maintenance.filter(m => m.estado === 'en_curso');
  const openMaintenanceFor = toolId => data.maintenance.find(m => m.toolId === toolId && m.estado === 'en_curso');

  const maintenanceDue = () => {
    const limit = U.addDays(U.today(), C.diasAvisoMantenimiento);
    return data.tools
      .filter(t => t.estado !== 'retirada' && t.proximoMantenimiento && t.proximoMantenimiento <= limit)
      .sort((a, b) => a.proximoMantenimiento.localeCompare(b.proximoMantenimiento));
  };

  const people = () => [...new Set(data.loans.flatMap(l => [l.asignadoA, l.retiradoPor]).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b, 'es'));

  function stats() {
    const byState = Object.fromEntries(Object.keys(C.estados).map(k => [k, 0]));
    const byCategory = {};
    data.tools.forEach(t => {
      byState[t.estado] = (byState[t.estado] || 0) + 1;
      byCategory[t.categoria] = (byCategory[t.categoria] || 0) + 1;
    });
    const operativas = data.tools.length - byState.retirada;
    return {
      total: data.tools.length,
      byState,
      byCategory,
      operativas,
      active: activeLoans().length,
      overdue: overdueLoans().length,
      maintDue: maintenanceDue().length,
      disponibilidad: operativas ? Math.round((byState.disponible / operativas) * 100) : 0,
    };
  }

  // Línea de tiempo de una herramienta: alta, salidas, devoluciones y mantenimientos
  function history(toolId) {
    const t = tool(toolId);
    if (!t) return [];
    const events = [{ fecha: t.creado, tipo: 'alta', titulo: 'Alta en inventario', detalle: [t.ubicacionTipo, t.ubicacionDetalle].filter(Boolean).join(', ') }];

    data.loans.filter(l => l.toolId === toolId).forEach(l => {
      events.push({
        fecha: l.fechaSalida, tipo: 'salida', titulo: `Salida a ${l.asignadoA}`,
        detalle: [`Retirada por ${l.retiradoPor}`, `devolución prevista ${U.fmtDate(l.fechaDevolucionEstimada)}`, l.destino && `destino ${l.destino}`].filter(Boolean).join(', ') + (l.notasSalida ? `. ${l.notasSalida}` : ''),
      });
      if (l.fechaDevolucionReal) {
        const retraso = U.daysBetween(l.fechaDevolucionEstimada, l.fechaDevolucionReal);
        events.push({
          fecha: l.fechaDevolucionReal, tipo: 'devolucion', titulo: `Devuelta por ${l.asignadoA}`,
          detalle: [l.condicionDevolucion === 'mantenimiento' ? 'Requiere mantenimiento' : 'En buen estado',
            retraso > 0 ? `${U.plural(retraso, 'día', 'días')} de retraso` : 'a tiempo'].join(', ') + (l.notasDevolucion ? `. ${l.notasDevolucion}` : ''),
        });
      }
    });

    data.maintenance.filter(m => m.toolId === toolId).forEach(m => {
      events.push({
        fecha: m.fecha, tipo: 'mantenimiento',
        titulo: m.estado === 'en_curso' ? `${m.tipo} en curso` : m.tipo,
        detalle: [m.descripcion, m.tecnico && `por ${m.tecnico}`, m.costo ? `costo ${U.money(m.costo)}` : '',
          m.fechaFin && m.fechaFin !== m.fecha ? `finalizado ${U.fmtDate(m.fechaFin)}` : '',
          m.proximaFecha && `próximo ${U.fmtDate(m.proximaFecha)}`].filter(Boolean).join('. '),
      });
    });

    const order = { alta: 0, salida: 1, mantenimiento: 2, devolucion: 3 };
    return events.sort((a, b) => b.fecha.localeCompare(a.fecha) || order[b.tipo] - order[a.tipo]);
  }

  function recentActivity(limit = 8) {
    return data.tools
      .flatMap(t => history(t.id).filter(e => e.tipo !== 'alta').map(e => ({ ...e, tool: t })))
      .sort((a, b) => b.fecha.localeCompare(a.fecha))
      .slice(0, limit);
  }

  /* ---------- Acciones: herramientas ---------- */
  function saveTool(input) {
    const sku = text(input.sku).toUpperCase();
    const nombre = text(input.nombre);
    if (!sku) fail('El código es obligatorio.');
    if (!/^[A-Z0-9][A-Z0-9._\-/]*$/.test(sku)) fail('El código solo admite letras, números, guiones, puntos y barras.');
    if (!nombre) fail('El nombre es obligatorio.');
    if (data.tools.some(t => t.sku === sku && t.id !== input.id)) fail(`El código ${sku} ya está registrado.`);

    const fields = {
      sku, nombre,
      categoria: input.categoria || C.categorias[0],
      estado: input.estado || 'disponible',
      marca: text(input.marca), modelo: text(input.modelo), numeroSerie: text(input.numeroSerie),
      ubicacionTipo: input.ubicacionTipo || C.ubicaciones[0], ubicacionDetalle: text(input.ubicacionDetalle),
      proximoMantenimiento: input.proximoMantenimiento || null,
      notas: text(input.notas),
      actualizado: U.today(),
    };

    if (input.id) {
      const t = tool(input.id) || fail('La herramienta ya no existe.');
      if (t.estado === 'en_uso' && fields.estado !== 'en_uso') fail('Registra la devolución antes de cambiar el estado de una herramienta prestada.');
      if (t.estado !== 'en_uso' && fields.estado === 'en_uso') fail('Para ponerla en uso, registra una salida.');
      if (fields.estado !== 'mantenimiento' && openMaintenanceFor(t.id)) fail('Tiene un mantenimiento en curso. Finalízalo desde Mantenimiento.');
      Object.assign(t, fields);
      commit();
      return t;
    }

    if (fields.estado === 'en_uso') fail('Registra la herramienta como disponible y luego registra la salida.');
    const t = { id: U.uid('t'), creado: U.today(), ...fields };
    data.tools.push(t);
    commit();
    return t;
  }

  function deleteTool(id) {
    if (activeLoanFor(id)) fail('No se puede eliminar una herramienta prestada. Registra primero la devolución.');
    data.tools = data.tools.filter(t => t.id !== id);
    data.loans = data.loans.filter(l => l.toolId !== id);
    data.maintenance = data.maintenance.filter(m => m.toolId !== id);
    commit();
  }

  /* ---------- Acciones: préstamos ---------- */
  function checkout(input) {
    const t = tool(input.toolId) || fail('Selecciona una herramienta válida.');
    if (t.estado !== 'disponible') fail(`${t.sku} no está disponible: ${C.estados[t.estado].label.toLowerCase()}.`);
    const asignadoA = text(input.asignadoA);
    const retiradoPor = text(input.retiradoPor);
    if (!asignadoA) fail('Indica el operario al que se asigna.');
    if (!retiradoPor) fail('Indica quién retira o autoriza la salida.');
    if (!input.fechaSalida || !input.fechaDevolucionEstimada) fail('Completa la fecha de salida y la devolución estimada.');
    if (input.fechaDevolucionEstimada < input.fechaSalida) fail('La devolución estimada no puede ser anterior a la salida.');

    const l = {
      id: U.uid('p'), toolId: t.id, asignadoA, retiradoPor,
      fechaSalida: input.fechaSalida, fechaDevolucionEstimada: input.fechaDevolucionEstimada, fechaDevolucionReal: null,
      destino: text(input.destino), notasSalida: text(input.notasSalida),
      ubicacionOrigen: { tipo: t.ubicacionTipo, detalle: t.ubicacionDetalle },
      condicionDevolucion: null, notasDevolucion: '',
    };
    data.loans.push(l);
    t.estado = 'en_uso';
    if (l.destino) { t.ubicacionTipo = 'Proyecto / obra'; t.ubicacionDetalle = l.destino; }
    t.actualizado = U.today();
    commit();
    return l;
  }

  function checkin(loanId, input) {
    const l = loan(loanId);
    if (!l || l.fechaDevolucionReal) fail('Este préstamo ya fue cerrado.');
    if (!input.fechaDevolucionReal) fail('Indica la fecha de devolución.');
    if (input.fechaDevolucionReal < l.fechaSalida) fail('La devolución no puede ser anterior a la salida.');

    l.fechaDevolucionReal = input.fechaDevolucionReal;
    l.condicionDevolucion = input.condicion === 'mantenimiento' ? 'mantenimiento' : 'buena';
    l.notasDevolucion = text(input.notasDevolucion);

    const t = tool(l.toolId);
    if (t) {
      t.ubicacionTipo = input.ubicacionTipo || l.ubicacionOrigen?.tipo || 'Almacén';
      t.ubicacionDetalle = text(input.ubicacionDetalle);
      t.actualizado = U.today();
      if (l.condicionDevolucion === 'mantenimiento') {
        t.estado = 'mantenimiento';
        data.maintenance.push({
          id: U.uid('m'), toolId: t.id, tipo: 'Reparación', estado: 'en_curso', fecha: l.fechaDevolucionReal, fechaFin: null,
          descripcion: l.notasDevolucion || 'Reportada con falla en la devolución', tecnico: '', costo: null, proximaFecha: null, resultado: null,
        });
      } else {
        t.estado = 'disponible';
      }
    }
    commit();
    return l;
  }

  /* ---------- Acciones: mantenimiento ---------- */
  function addMaintenance(input) {
    const t = tool(input.toolId) || fail('Selecciona una herramienta válida.');
    if (!text(input.descripcion)) fail('Describe el trabajo o la falla.');
    if (!input.fecha) fail('Indica la fecha.');
    const enCurso = input.modalidad === 'en_curso';
    if (enCurso && t.estado === 'en_uso') fail(`${t.sku} está prestada. Registra la devolución antes de enviarla a mantenimiento.`);
    if (enCurso && openMaintenanceFor(t.id)) fail(`${t.sku} ya tiene un mantenimiento en curso.`);
    if (input.proximaFecha && input.proximaFecha < input.fecha) fail('La próxima fecha debe ser posterior a la del trabajo.');

    const m = {
      id: U.uid('m'), toolId: t.id, tipo: input.tipo || C.tiposMantenimiento[0],
      estado: enCurso ? 'en_curso' : 'completado', fecha: input.fecha, fechaFin: enCurso ? null : input.fecha,
      descripcion: text(input.descripcion), tecnico: text(input.tecnico),
      costo: input.costo === '' || input.costo === undefined ? null : Number(input.costo),
      proximaFecha: input.proximaFecha || null, resultado: enCurso ? null : t.estado,
    };
    data.maintenance.push(m);
    if (enCurso) t.estado = 'mantenimiento';
    if (m.proximaFecha) t.proximoMantenimiento = m.proximaFecha;
    t.actualizado = U.today();
    commit();
    return m;
  }

  function completeMaintenance(id, input) {
    const m = data.maintenance.find(x => x.id === id);
    if (!m || m.estado !== 'en_curso') fail('Este mantenimiento ya fue finalizado.');
    if (!input.fechaFin) fail('Indica la fecha de finalización.');
    if (input.fechaFin < m.fecha) fail('La finalización no puede ser anterior al inicio.');
    m.estado = 'completado';
    m.fechaFin = input.fechaFin;
    m.costo = input.costo === '' || input.costo === undefined ? m.costo : Number(input.costo);
    m.tecnico = text(input.tecnico) || m.tecnico;
    if (text(input.notas)) m.descripcion = `${m.descripcion}. ${text(input.notas)}`;
    m.resultado = input.resultado === 'retirada' ? 'retirada' : 'disponible';
    m.proximaFecha = input.proximaFecha || null;

    const t = tool(m.toolId);
    if (t) {
      t.estado = m.resultado;
      if (m.proximaFecha) t.proximoMantenimiento = m.proximaFecha;
      t.actualizado = U.today();
    }
    commit();
    return m;
  }

  /* ---------- Respaldo ---------- */
  const exportJSON = () => JSON.stringify({ ...data, exportado: new Date().toISOString() }, null, 2);
  function importJSON(raw) {
    let parsed;
    try { parsed = JSON.parse(raw); } catch { fail('El archivo no es un JSON válido.'); }
    if (!Array.isArray(parsed?.tools)) fail('El archivo no tiene el formato de respaldo de esta app.');
    data = normalize(parsed);
    commit();
  }
  const loadDemo = () => { data = TM.seed(); commit(); };
  const clearAll = () => { data = normalize({}); commit(); };

  return {
    init, subscribe,
    tools, tool, toolBySku, loans, loan, activeLoans, activeLoanFor, isOverdue, overdueLoans,
    maintenance, openMaintenance, openMaintenanceFor, maintenanceDue, people, stats, history, recentActivity,
    saveTool, deleteTool, checkout, checkin, addMaintenance, completeMaintenance,
    exportJSON, importJSON, loadDemo, clearAll,
  };
})();
