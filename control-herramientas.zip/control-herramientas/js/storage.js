/*
 * Capa de almacenamiento.
 * La app solo habla con TM.storage.load / save / subscribe, así que para conectar
 * una base de datos basta con registrar otro adaptador con TM.storage.use(adapter).
 * load() puede devolver los datos o una Promesa (útil para APIs remotas).
 */
window.TM = window.TM || {};

TM.storage = (() => {
  const key = TM.config.STORAGE_KEY;

  const localAdapter = {
    name: 'localStorage',
    load() {
      try {
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : null;
      } catch (err) {
        console.warn('No se pudo leer el almacenamiento local:', err);
        return null;
      }
    },
    save(data) {
      try {
        localStorage.setItem(key, JSON.stringify(data));
        return true;
      } catch (err) {
        console.error('No se pudo guardar en el almacenamiento local:', err);
        return false;
      }
    },
    // Sincroniza entre pestañas abiertas del mismo navegador
    subscribe(callback) {
      window.addEventListener('storage', e => {
        if (e.key === key && e.newValue) {
          try { callback(JSON.parse(e.newValue)); } catch { /* ignorar datos corruptos */ }
        }
      });
    },
  };

  let adapter = localAdapter;

  return {
    use(next) { adapter = next; },
    get name() { return adapter.name; },
    load: () => adapter.load(),
    save: data => adapter.save(data),
    subscribe: cb => adapter.subscribe && adapter.subscribe(cb),
  };
})();
