/* Piezas de interfaz reutilizables: íconos, etiquetas, campos, modal, confirmación y avisos. */
window.TM = window.TM || {};

TM.ui = (() => {
  const U = TM.utils;
  const C = TM.config;

  const icon = name => `<svg class="i" aria-hidden="true"><use href="#i-${name}"></use></svg>`;

  const stateBadge = estado => {
    const s = C.estados[estado] || { label: estado, tone: 'muted' };
    return `<span class="badge tone-${s.tone}"><span class="dot"></span>${s.label}</span>`;
  };

  const skuTag = sku => `<span class="tag">${U.esc(sku)}</span>`;

  // Etiqueta de plazo de un préstamo activo
  const dueBadge = loan => {
    const d = U.daysBetween(U.today(), loan.fechaDevolucionEstimada);
    if (d < 0) return `<span class="badge tone-danger">${icon('alert')}Atrasada ${U.plural(-d, 'día', 'días')}</span>`;
    if (d === 0) return '<span class="badge tone-warn">Vence hoy</span>';
    if (d === 1) return '<span class="badge tone-warn">Vence mañana</span>';
    return `<span class="badge tone-muted">Faltan ${d} días</span>`;
  };

  const maintDueBadge = iso => {
    const d = U.daysBetween(U.today(), iso);
    if (d < 0) return `<span class="badge tone-danger">${icon('alert')}Vencido hace ${U.plural(-d, 'día', 'días')}</span>`;
    if (d === 0) return '<span class="badge tone-warn">Hoy</span>';
    return `<span class="badge tone-warn">En ${U.plural(d, 'día', 'días')}</span>`;
  };

  const field = (label, control, { hint = '', full = false } = {}) =>
    `<label class="field${full ? ' full' : ''}"><span class="field-label">${label}</span>${control}${hint ? `<span class="hint">${hint}</span>` : ''}</label>`;

  const options = (list, selected) => list.map(o => {
    const [value, label] = Array.isArray(o) ? o : [o, o];
    return `<option value="${U.esc(value)}"${value === selected ? ' selected' : ''}>${U.esc(label)}</option>`;
  }).join('');

  const empty = (title, text, actions = '') =>
    `<div class="empty"><p class="empty-title">${title}</p><p>${text}</p>${actions ? `<div class="empty-actions">${actions}</div>` : ''}</div>`;

  /* ---------- Modal ---------- */
  const root = () => document.getElementById('modal-root');
  let lastFocus = null;

  const onKey = e => { if (e.key === 'Escape') closeModal(); };

  function closeModal() {
    const r = root();
    if (!r.classList.contains('open')) return;
    r.classList.remove('open');
    r.innerHTML = '';
    document.removeEventListener('keydown', onKey);
    document.body.classList.remove('no-scroll');
    if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
  }

  /**
   * Abre un modal con formulario. onSubmit recibe los valores del formulario;
   * si lanza un Error, el mensaje se muestra dentro del modal y no se cierra.
   */
  function openModal({ title, subtitle = '', body, submitLabel = 'Guardar', onSubmit = null, size = 'md', danger = false, footer = null }) {
    if (root().classList.contains('open')) {
      root().innerHTML = '';
      document.removeEventListener('keydown', onKey);
    } else {
      lastFocus = document.activeElement;
    }
    const r = root();
    r.innerHTML = `
      <div class="modal-backdrop" data-close></div>
      <div class="modal modal-${size}" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <form class="modal-form">
          <header class="modal-head">
            <div><h2 id="modal-title">${title}</h2>${subtitle ? `<p class="modal-sub">${subtitle}</p>` : ''}</div>
            <button type="button" class="icon-btn" data-close aria-label="Cerrar">${icon('x')}</button>
          </header>
          <div class="modal-body">${body}</div>
          <p class="form-error" role="alert" hidden></p>
          <footer class="modal-foot">${footer ?? `
            <button type="button" class="btn btn-ghost" data-close>Cancelar</button>
            ${onSubmit ? `<button type="submit" class="btn ${danger ? 'btn-danger' : 'btn-primary'}">${submitLabel}</button>` : ''}`}
          </footer>
        </form>
      </div>`;
    r.classList.add('open');
    document.body.classList.add('no-scroll');
    document.addEventListener('keydown', onKey);

    const form = r.querySelector('form');
    const error = r.querySelector('.form-error');
    r.querySelectorAll('[data-close]').forEach(el => el.addEventListener('click', closeModal));
    form.addEventListener('submit', e => {
      e.preventDefault();
      if (!onSubmit) return closeModal();
      try {
        const result = onSubmit(Object.fromEntries(new FormData(form)), form);
        if (result !== false) closeModal();
      } catch (err) {
        error.textContent = err.message;
        error.hidden = false;
        error.scrollIntoView({ block: 'nearest' });
      }
    });

    requestAnimationFrame(() => {
      const target = form.querySelector('[autofocus]') || form.querySelector('input:not([type=hidden]), select, textarea');
      (target || form.querySelector('button'))?.focus();
    });
    return r.querySelector('.modal');
  }

  function confirmDialog({ title, text, confirmLabel = 'Confirmar', danger = false }) {
    return new Promise(resolve => {
      let answered = false;
      openModal({
        title, body: `<p>${text}</p>`, submitLabel: confirmLabel, danger, size: 'sm',
        onSubmit: () => { answered = true; resolve(true); },
      });
      const observer = new MutationObserver(() => {
        if (!root().classList.contains('open')) { observer.disconnect(); if (!answered) resolve(false); }
      });
      observer.observe(root(), { attributes: true, attributeFilter: ['class'] });
    });
  }

  /* ---------- Avisos ---------- */
  function toast(message, tone = 'ok') {
    const el = document.createElement('div');
    el.className = `toast tone-${tone}`;
    el.textContent = message;
    document.getElementById('toast-root').appendChild(el);
    setTimeout(() => el.classList.add('leaving'), 2800);
    setTimeout(() => el.remove(), 3200);
  }

  return { icon, stateBadge, skuTag, dueBadge, maintDueBadge, field, options, empty, openModal, closeModal, confirmDialog, toast };
})();
