/* Arranque: enrutador por hash, búsqueda global, acciones delegadas y alertas. */
window.TM = window.TM || {};

(() => {
  const S = TM.store, U = TM.utils;
  const { toast, confirmDialog, closeModal } = TM.ui;

  TM.state = {
    query: '',
    inv: { ...TM.views.inventario.defaults },
    loansTab: 'activos',
    maintTipo: '',
  };

  const viewEl = document.getElementById('view');
  const search = document.getElementById('global-search');

  const currentRoute = () => {
    const r = location.hash.replace(/^#\/?/, '').split('?')[0];
    return TM.views[r] ? r : 'panel';
  };

  let lastRoute = null;
  function render() {
    const route = currentRoute();
    const view = TM.views[route];
    view.render(viewEl);
    document.title = `${view.title} | Bodega de herramientas`;
    search.placeholder = view.searchPlaceholder;
    document.querySelectorAll('.nav a').forEach(a => a.classList.toggle('active', a.dataset.route === route));
    if (route !== lastRoute) { window.scrollTo(0, 0); lastRoute = route; }
    updateAlerts();
  }

  function go(route) {
    if (currentRoute() === route) render();
    else location.hash = `#/${route}`;
  }

  /* Insignias del menú y banner de atrasos */
  function updateAlerts() {
    const overdue = S.overdueLoans();
    const maint = S.maintenanceDue().length + S.openMaintenance().length;
    const bo = document.getElementById('badge-overdue');
    const bm = document.getElementById('badge-maint');
    bo.hidden = !overdue.length; bo.textContent = overdue.length;
    bm.hidden = !maint; bm.textContent = maint;

    const banner = document.getElementById('overdue-banner');
    const showBanner = overdue.length && !(currentRoute() === 'prestamos' && TM.state.loansTab === 'atrasados');
    banner.hidden = !showBanner;
    if (showBanner) {
      const names = [...new Set(overdue.map(l => l.asignadoA))];
      banner.innerHTML = `${TM.ui.icon('alert')}<span><strong>${U.plural(overdue.length, 'devolución atrasada', 'devoluciones atrasadas')}</strong>
        <span class="banner-detail">Pendiente con ${U.esc(names.slice(0, 3).join(', '))}${names.length > 3 ? ` y ${names.length - 3} más` : ''}</span></span>
        <button type="button" class="btn btn-small btn-danger" data-action="loans-tab" data-tab="atrasados">Ver atrasadas</button>`;
    }
  }

  /* Búsqueda global en tiempo real, contextual a la vista actual */
  const runSearch = U.debounce(() => {
    TM.state.query = search.value;
    const route = currentRoute();
    if (route === 'panel') { if (search.value.trim()) go('inventario'); return; }
    TM.views[route].onSearch(viewEl);
  }, 80);
  search.addEventListener('input', runSearch);
  search.addEventListener('keydown', e => { if (e.key === 'Escape' && search.value) { search.value = ''; runSearch(); } });

  document.addEventListener('keydown', e => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName);
    if (e.key === '/' && !typing && !document.getElementById('modal-root').classList.contains('open')) {
      e.preventDefault(); search.focus(); search.select();
    }
  });

  const clearSearch = () => { search.value = ''; TM.state.query = ''; };

  /* Acciones disponibles mediante data-action en cualquier botón */
  const actions = {
    'new-tool': () => TM.forms.toolForm(),
    'edit-tool': el => TM.forms.toolForm(el.dataset.id),
    'delete-tool': el => TM.forms.deleteTool(el.dataset.id),
    'detail': el => TM.forms.toolDetail(el.dataset.id),
    'checkout': el => TM.forms.checkoutForm(el.dataset.id),
    'checkin': el => TM.forms.checkinForm(el.dataset.loan),
    'maintenance': el => TM.forms.maintenanceForm(el.dataset.id),
    'complete-maint': el => TM.forms.completeMaintenanceForm(el.dataset.id),
    'go': el => { closeModal(); go(el.dataset.route); },
    'filter-state': el => {
      clearSearch();
      TM.state.inv = { ...TM.views.inventario.defaults, estado: el.dataset.state };
      go('inventario');
    },
    'filter-category': el => {
      clearSearch();
      TM.state.inv = { ...TM.views.inventario.defaults, categoria: el.dataset.category };
      go('inventario');
    },
    'loans-tab': el => { closeModal(); TM.state.loansTab = el.dataset.tab; go('prestamos'); },
    'clear-filters': () => { clearSearch(); TM.state.inv = { ...TM.views.inventario.defaults }; render(); },
    'export': () => {
      const blob = new Blob([S.exportJSON()], { type: 'application/json' });
      const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: `respaldo-herramientas-${U.today()}.json` });
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      toast('Respaldo exportado');
    },
    'reset-demo': async () => {
      const ok = !S.tools().length || await confirmDialog({
        title: 'Cargar datos de ejemplo', text: 'Se reemplazarán los datos actuales por un inventario de ejemplo. Exporta un respaldo si quieres conservarlos.',
        confirmLabel: 'Reemplazar datos', danger: true,
      });
      if (ok) { S.loadDemo(); toast('Datos de ejemplo cargados'); }
    },
    'clear-all': async () => {
      const ok = await confirmDialog({
        title: 'Borrar todos los datos', text: 'Se eliminarán todas las herramientas, préstamos y mantenimientos de este navegador. Esta acción no se puede deshacer.',
        confirmLabel: 'Borrar todo', danger: true,
      });
      if (ok) { S.clearAll(); toast('Datos borrados'); }
    },
  };

  document.addEventListener('click', e => {
    const el = e.target.closest('[data-action]');
    if (!el || !actions[el.dataset.action]) return;
    // Los botones dentro de un modal de ficha abren otro modal en su lugar
    actions[el.dataset.action](el);
    el.closest('details')?.removeAttribute('open');
  });

  document.getElementById('import-file').addEventListener('change', async e => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    try {
      S.importJSON(await file.text());
      toast('Respaldo importado');
    } catch (err) {
      toast(err.message, 'danger');
    }
    document.querySelector('.data-menu')?.removeAttribute('open');
  });

  window.addEventListener('hashchange', render);

  /* Recalcula atrasos al cambiar el día (pestaña abierta durante la noche) */
  let day = U.today();
  setInterval(() => { if (U.today() !== day) { day = U.today(); render(); } }, 60000);

  S.init().then(() => {
    S.subscribe(render);
    render();
  });
})();
