/* Vista: Préstamos activos, atrasados e historial de devoluciones. */
window.TM = window.TM || {};
TM.views = TM.views || {};

TM.views.prestamos = {
  title: 'Préstamos',
  searchPlaceholder: 'Buscar por código, herramienta, operario, quien retira o destino',

  rowsFor(tab) {
    const S = TM.store, U = TM.utils;
    let list;
    if (tab === 'atrasados') list = S.overdueLoans();
    else if (tab === 'historial') list = S.loans().filter(l => l.fechaDevolucionReal);
    else list = S.activeLoans();

    const q = TM.state.query;
    list = list.filter(l => {
      const t = S.tool(l.toolId);
      return t && U.matches(q, [t.sku, t.nombre, t.categoria, l.asignadoA, l.retiradoPor, l.destino, l.notasSalida, l.notasDevolucion]);
    });
    return tab === 'historial'
      ? list.sort((a, b) => b.fechaDevolucionReal.localeCompare(a.fechaDevolucionReal))
      : list.sort((a, b) => a.fechaDevolucionEstimada.localeCompare(b.fechaDevolucionEstimada));
  },

  render(el) {
    const S = TM.store;
    const { icon } = TM.ui;
    const tab = TM.state.loansTab;
    const counts = { activos: S.activeLoans().length, atrasados: S.overdueLoans().length, historial: S.loans().filter(l => l.fechaDevolucionReal).length };
    const tabs = [['activos', 'Activos'], ['atrasados', 'Atrasados'], ['historial', 'Devueltos']];

    el.innerHTML = `
      <section class="page-head">
        <div><h1>Préstamos</h1><p class="text-muted">Salidas y devoluciones de herramientas</p></div>
        <div class="page-actions">
          <button type="button" class="btn btn-primary" data-action="checkout">${icon('out')}Registrar salida</button>
        </div>
      </section>
      <div class="tabs" role="tablist">
        ${tabs.map(([k, label]) => `<button type="button" role="tab" aria-selected="${tab === k}" class="tab${tab === k ? ' active' : ''}${k === 'atrasados' && counts.atrasados ? ' tab-alert' : ''}" data-action="loans-tab" data-tab="${k}">
          ${label}<span class="count">${counts[k]}</span></button>`).join('')}
      </div>
      <div id="loan-results"></div>`;
    this.renderResults(el);
  },

  renderResults(el) {
    const S = TM.store, U = TM.utils;
    const { skuTag, dueBadge, empty, icon } = TM.ui;
    const esc = U.esc;
    const tab = TM.state.loansTab;
    const rows = this.rowsFor(tab);
    const box = el.querySelector('#loan-results');

    if (!rows.length) {
      const msg = TM.state.query
        ? ['Sin resultados', 'Ningún préstamo coincide con la búsqueda.']
        : {
          activos: ['No hay herramientas prestadas', 'Cuando registres una salida aparecerá aquí con su fecha de devolución.'],
          atrasados: ['Todo al día', 'Ningún préstamo ha superado su fecha de devolución.'],
          historial: ['Sin devoluciones todavía', 'Aquí verás los préstamos cerrados y si volvieron a tiempo.'],
        }[tab];
      box.innerHTML = empty(msg[0], msg[1], tab === 'activos' && !TM.state.query ? `<button class="btn btn-primary" data-action="checkout">${icon('out')}Registrar salida</button>` : '');
      return;
    }

    const toolCell = t => `<td data-label="Herramienta"><span class="cell-tool">${skuTag(t.sku)}<button type="button" class="cell-title" data-action="detail" data-id="${t.id}">${esc(t.nombre)}</button></span></td>`;

    if (tab === 'historial') {
      box.innerHTML = `<div class="table-wrap"><table class="data">
        <thead><tr><th>Herramienta</th><th>Asignada a</th><th>Salida</th><th>Devuelta</th><th>Cumplimiento</th><th>Condición</th></tr></thead>
        <tbody>${rows.map(l => {
          const t = S.tool(l.toolId);
          const retraso = U.daysBetween(l.fechaDevolucionEstimada, l.fechaDevolucionReal);
          return `<tr data-action="detail" data-id="${t.id}">
            ${toolCell(t)}
            <td data-label="Asignada a">${esc(l.asignadoA)}<small class="text-muted">Retiró ${esc(l.retiradoPor)}</small></td>
            <td data-label="Salida">${U.fmtDate(l.fechaSalida)}</td>
            <td data-label="Devuelta">${U.fmtDate(l.fechaDevolucionReal)}</td>
            <td data-label="Cumplimiento">${retraso > 0 ? `<span class="badge tone-danger">${U.plural(retraso, 'día', 'días')} tarde</span>` : '<span class="badge tone-ok">A tiempo</span>'}</td>
            <td data-label="Condición">${l.condicionDevolucion === 'mantenimiento' ? '<span class="badge tone-warn">Con falla</span>' : 'Buena'}${l.notasDevolucion ? `<small class="text-muted">${esc(l.notasDevolucion)}</small>` : ''}</td>
          </tr>`;
        }).join('')}</tbody></table></div>`;
      return;
    }

    box.innerHTML = `<div class="table-wrap"><table class="data">
      <thead><tr><th>Herramienta</th><th>Asignada a</th><th>Retirada por</th><th>Salida</th><th>Devolución estimada</th><th>Plazo</th><th class="col-actions"><span class="sr-only">Acciones</span></th></tr></thead>
      <tbody>${rows.map(l => {
        const t = S.tool(l.toolId);
        const late = S.isOverdue(l);
        return `<tr class="${late ? 'row-overdue' : ''}" data-action="detail" data-id="${t.id}">
          ${toolCell(t)}
          <td data-label="Asignada a">${esc(l.asignadoA)}${l.destino ? `<small class="text-muted">${esc(l.destino)}</small>` : ''}</td>
          <td data-label="Retirada por">${esc(l.retiradoPor)}</td>
          <td data-label="Salida">${U.fmtDate(l.fechaSalida)}</td>
          <td data-label="Devolución estimada">${U.fmtDate(l.fechaDevolucionEstimada)}</td>
          <td data-label="Plazo">${dueBadge(l)}</td>
          <td class="col-actions"><button type="button" class="btn btn-small ${late ? 'btn-danger' : 'btn-secondary'}" data-action="checkin" data-loan="${l.id}">${icon('in')}Devolver</button></td>
        </tr>`;
      }).join('')}</tbody></table></div>`;
  },

  onSearch(el) { this.renderResults(el); },
};
