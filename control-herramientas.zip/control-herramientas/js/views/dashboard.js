/* Vista: Panel de control con métricas, alertas y actividad. */
window.TM = window.TM || {};
TM.views = TM.views || {};

TM.views.panel = {
  title: 'Panel',
  searchPlaceholder: 'Buscar herramienta por código, nombre, categoría o responsable',

  render(el) {
    const U = TM.utils, S = TM.store, C = TM.config;
    const { icon, skuTag, dueBadge, maintDueBadge, stateBadge, empty } = TM.ui;
    const esc = U.esc;
    const s = S.stats();

    if (!s.total) {
      el.innerHTML = `<section class="page-head"><h1>Panel de control</h1></section>
        ${empty('Tu inventario está vacío', 'Registra la primera herramienta o carga los datos de ejemplo para explorar la app.',
          `<button class="btn btn-primary" data-action="new-tool">${icon('plus')}Nueva herramienta</button>
           <button class="btn btn-secondary" data-action="reset-demo">Cargar datos de ejemplo</button>`)}`;
      return;
    }

    const overdue = S.overdueLoans().sort((a, b) => a.fechaDevolucionEstimada.localeCompare(b.fechaDevolucionEstimada));
    const dueSoon = S.activeLoans().filter(l => !S.isOverdue(l) && U.daysBetween(U.today(), l.fechaDevolucionEstimada) <= 2);
    const maintDue = S.maintenanceDue();
    const activity = S.recentActivity(7);
    const categories = Object.entries(s.byCategory).sort((a, b) => b[1] - a[1]);
    const maxCat = Math.max(...categories.map(c => c[1]));

    const segments = Object.entries(C.estados)
      .filter(([k]) => s.byState[k])
      .map(([k, v]) => `<button type="button" class="seg tone-${v.tone}" style="flex:${s.byState[k]}" data-action="filter-state" data-state="${k}"
          title="${v.label}: ${s.byState[k]}" aria-label="${v.label}: ${s.byState[k]}. Ver en inventario"></button>`).join('');

    const loanRow = l => {
      const t = S.tool(l.toolId);
      return `<li class="row-item">
        <button type="button" class="row-main" data-action="detail" data-id="${t.id}">
          ${skuTag(t.sku)}<span class="row-text"><strong>${esc(t.nombre)}</strong><small>${esc(l.asignadoA)}, devolución ${U.fmtDate(l.fechaDevolucionEstimada)}</small></span>
        </button>
        ${dueBadge(l)}
        <button type="button" class="btn btn-small btn-secondary" data-action="checkin" data-loan="${l.id}">Devolver</button>
      </li>`;
    };

    el.innerHTML = `
      <section class="page-head">
        <div>
          <h1>Panel de control</h1>
          <p class="text-muted">Estado del inventario hoy, ${U.fmtDate(U.today())}</p>
        </div>
      </section>

      <section class="kpis" aria-label="Resumen">
        <button type="button" class="kpi" data-action="filter-state" data-state="">
          <span class="kpi-label">Herramientas registradas</span><strong class="kpi-value">${s.total}</strong>
          <span class="kpi-sub">${s.operativas} operativas, ${s.byState.retirada} retiradas</span>
        </button>
        <button type="button" class="kpi kpi-ok" data-action="filter-state" data-state="disponible">
          <span class="kpi-label">Disponibles</span><strong class="kpi-value">${s.byState.disponible}</strong>
          <span class="kpi-sub">${s.disponibilidad}% de las operativas</span>
        </button>
        <button type="button" class="kpi kpi-info" data-action="filter-state" data-state="en_uso">
          <span class="kpi-label">Prestadas</span><strong class="kpi-value">${s.byState.en_uso}</strong>
          <span class="kpi-sub">${dueSoon.length ? `${U.plural(dueSoon.length, 'vence', 'vencen')} en 2 días` : 'Ninguna vence pronto'}</span>
        </button>
        <button type="button" class="kpi kpi-warn" data-action="filter-state" data-state="mantenimiento">
          <span class="kpi-label">En mantenimiento</span><strong class="kpi-value">${s.byState.mantenimiento}</strong>
          <span class="kpi-sub">${s.maintDue ? `${U.plural(s.maintDue, 'preventivo próximo', 'preventivos próximos')}` : 'Sin preventivos próximos'}</span>
        </button>
        <button type="button" class="kpi kpi-danger${s.overdue ? ' is-alert' : ''}" data-action="loans-tab" data-tab="atrasados">
          <span class="kpi-label">Devoluciones atrasadas</span><strong class="kpi-value">${s.overdue}</strong>
          <span class="kpi-sub">${s.overdue ? 'Requieren seguimiento' : 'Todo al día'}</span>
        </button>
      </section>

      <section class="panel">
        <header class="panel-head"><h2>Estado del inventario</h2><span class="text-muted">Toca un tramo para ver esas herramientas</span></header>
        <div class="stack-bar">${segments}</div>
        <ul class="legend">
          ${Object.entries(C.estados).map(([k, v]) => `<li><span class="sw tone-${v.tone}"></span>${v.label}<strong>${s.byState[k]}</strong></li>`).join('')}
        </ul>
      </section>

      <div class="dash-grid">
        <section class="panel${overdue.length ? ' panel-alert' : ''}">
          <header class="panel-head"><h2>${icon('alert')}Devoluciones atrasadas</h2>
            ${overdue.length ? '<button type="button" class="link-btn" data-action="loans-tab" data-tab="atrasados">Ver todas</button>' : ''}</header>
          ${overdue.length ? `<ul class="rows">${overdue.slice(0, 6).map(loanRow).join('')}</ul>`
            : '<p class="panel-empty">No hay préstamos vencidos. Las herramientas atrasadas aparecerán aquí.</p>'}
        </section>

        <section class="panel">
          <header class="panel-head"><h2>${icon('clock')}Mantenimiento próximo</h2>
            <button type="button" class="link-btn" data-action="go" data-route="mantenimiento">Ver mantenimiento</button></header>
          ${maintDue.length ? `<ul class="rows">${maintDue.slice(0, 6).map(t => `<li class="row-item">
              <button type="button" class="row-main" data-action="detail" data-id="${t.id}">
                ${skuTag(t.sku)}<span class="row-text"><strong>${esc(t.nombre)}</strong><small>Programado ${U.fmtDate(t.proximoMantenimiento)}</small></span>
              </button>
              ${maintDueBadge(t.proximoMantenimiento)}
              <button type="button" class="btn btn-small btn-secondary" data-action="maintenance" data-id="${t.id}">Registrar</button>
            </li>`).join('')}</ul>`
            : `<p class="panel-empty">Nada programado en los próximos ${C.diasAvisoMantenimiento} días.</p>`}
        </section>

        <section class="panel">
          <header class="panel-head"><h2>Por categoría</h2></header>
          <ul class="bars">
            ${categories.map(([cat, n]) => `<li>
              <button type="button" class="bar-row" data-action="filter-category" data-category="${esc(cat)}">
                <span class="bar-label">${esc(cat)}</span>
                <span class="bar-track"><span class="bar-fill" style="width:${(n / maxCat) * 100}%"></span></span>
                <span class="bar-value">${n}</span>
              </button></li>`).join('')}
          </ul>
        </section>

        <section class="panel">
          <header class="panel-head"><h2>Actividad reciente</h2></header>
          ${activity.length ? `<ol class="activity">${activity.map(e => `<li class="ev-${e.tipo}">
              <span class="ev-date">${U.fmtDate(e.fecha)}</span>
              <button type="button" class="link-btn" data-action="detail" data-id="${e.tool.id}">${esc(e.tool.sku)}</button>
              <span>${esc(e.titulo)}</span>
            </li>`).join('')}</ol>` : '<p class="panel-empty">Los préstamos y mantenimientos aparecerán aquí.</p>'}
        </section>
      </div>`;
  },
};
