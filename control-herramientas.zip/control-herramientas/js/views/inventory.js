/* Vista: Inventario con búsqueda en tiempo real y filtros combinables. */
window.TM = window.TM || {};
TM.views = TM.views || {};

TM.views.inventario = {
  title: 'Inventario',
  searchPlaceholder: 'Buscar por código, nombre, categoría, marca, ubicación o responsable',
  defaults: { categoria: '', estado: '', ubicacion: '', soloAtrasadas: false, orden: 'sku' },

  filtered() {
    const S = TM.store, U = TM.utils;
    const f = TM.state.inv;
    const q = TM.state.query;
    const rows = S.tools().filter(t => {
      if (f.categoria && t.categoria !== f.categoria) return false;
      if (f.estado && t.estado !== f.estado) return false;
      if (f.ubicacion && t.ubicacionTipo !== f.ubicacion) return false;
      const l = S.activeLoanFor(t.id);
      if (f.soloAtrasadas && !(l && S.isOverdue(l))) return false;
      return U.matches(q, [t.sku, t.nombre, t.categoria, t.marca, t.modelo, t.numeroSerie, t.ubicacionTipo, t.ubicacionDetalle,
        TM.config.estados[t.estado]?.label, l?.asignadoA, l?.retiradoPor]);
    });
    const sorters = {
      sku: U.bySku,
      nombre: (a, b) => a.nombre.localeCompare(b.nombre, 'es'),
      estado: (a, b) => a.estado.localeCompare(b.estado) || U.bySku(a, b),
      categoria: (a, b) => a.categoria.localeCompare(b.categoria, 'es') || U.bySku(a, b),
      actualizado: (a, b) => (b.actualizado || '').localeCompare(a.actualizado || ''),
    };
    return rows.sort(sorters[f.orden] || U.bySku);
  },

  render(el) {
    const C = TM.config, U = TM.utils;
    const { options } = TM.ui;
    const f = TM.state.inv;
    const estadoOpts = [['', 'Todos los estados'], ...Object.entries(C.estados).map(([k, v]) => [k, v.label])];

    el.innerHTML = `
      <section class="page-head">
        <div><h1>Inventario</h1><p class="text-muted" id="inv-count"></p></div>
      </section>
      <section class="filters" aria-label="Filtros">
        <label class="filter"><span class="sr-only">Categoría</span>
          <select data-filter="categoria">${options([['', 'Todas las categorías'], ...C.categorias], f.categoria)}</select></label>
        <label class="filter"><span class="sr-only">Estado</span>
          <select data-filter="estado">${options(estadoOpts, f.estado)}</select></label>
        <label class="filter"><span class="sr-only">Ubicación</span>
          <select data-filter="ubicacion">${options([['', 'Todas las ubicaciones'], ...C.ubicaciones], f.ubicacion)}</select></label>
        <label class="filter"><span class="sr-only">Ordenar</span>
          <select data-filter="orden">${options([['sku', 'Ordenar por código'], ['nombre', 'Ordenar por nombre'], ['categoria', 'Ordenar por categoría'], ['estado', 'Ordenar por estado'], ['actualizado', 'Modificadas recientemente']], f.orden)}</select></label>
        <label class="toggle"><input type="checkbox" data-filter="soloAtrasadas" ${f.soloAtrasadas ? 'checked' : ''}><span>Solo con devolución atrasada</span></label>
        <button type="button" class="link-btn" data-action="clear-filters" id="clear-filters" hidden>Limpiar filtros</button>
      </section>
      <div id="inv-results"></div>`;

    el.querySelectorAll('[data-filter]').forEach(input => {
      input.addEventListener('change', () => {
        TM.state.inv[input.dataset.filter] = input.type === 'checkbox' ? input.checked : input.value;
        this.renderResults(el);
      });
    });
    this.renderResults(el);
  },

  renderResults(el) {
    const S = TM.store, U = TM.utils;
    const { stateBadge, skuTag, dueBadge, icon, empty } = TM.ui;
    const esc = U.esc;
    const rows = this.filtered();
    const total = S.tools().length;
    const f = TM.state.inv;
    const hasFilters = TM.state.query || f.categoria || f.estado || f.ubicacion || f.soloAtrasadas;

    el.querySelector('#inv-count').textContent = hasFilters
      ? `${rows.length} de ${U.plural(total, 'herramienta', 'herramientas')}${TM.state.query ? ` para «${TM.state.query}»` : ''}`
      : U.plural(total, 'herramienta registrada', 'herramientas registradas');
    el.querySelector('#clear-filters').hidden = !hasFilters;

    const box = el.querySelector('#inv-results');
    if (!rows.length) {
      box.innerHTML = total
        ? empty('Ninguna herramienta coincide', 'Prueba con otro término o quita algún filtro.', '<button class="btn btn-secondary" data-action="clear-filters">Limpiar filtros</button>')
        : empty('Aún no hay herramientas', 'Registra la primera para empezar a controlar préstamos y mantenimientos.', `<button class="btn btn-primary" data-action="new-tool">${icon('plus')}Nueva herramienta</button>`);
      return;
    }

    box.innerHTML = `<div class="table-wrap"><table class="data">
      <thead><tr><th>Código</th><th>Herramienta</th><th>Categoría</th><th>Estado</th><th>Ubicación</th><th>Responsable</th><th class="col-actions"><span class="sr-only">Acciones</span></th></tr></thead>
      <tbody>${rows.map(t => {
        const l = S.activeLoanFor(t.id);
        const om = S.openMaintenanceFor(t.id);
        const late = l && S.isOverdue(l);
        const action = t.estado === 'disponible'
          ? `<button type="button" class="btn btn-small btn-secondary" data-action="checkout" data-id="${t.id}">Prestar</button>`
          : l ? `<button type="button" class="btn btn-small ${late ? 'btn-danger' : 'btn-secondary'}" data-action="checkin" data-loan="${l.id}">Devolver</button>`
          : om ? `<button type="button" class="btn btn-small btn-secondary" data-action="complete-maint" data-id="${om.id}">Finalizar</button>` : '';
        return `<tr class="${late ? 'row-overdue' : ''}" data-action="detail" data-id="${t.id}">
          <td data-label="Código">${skuTag(t.sku)}</td>
          <td data-label="Herramienta"><button type="button" class="cell-title" data-action="detail" data-id="${t.id}">${esc(t.nombre)}</button>
            ${t.marca || t.modelo ? `<small class="text-muted">${esc([t.marca, t.modelo].filter(Boolean).join(' '))}</small>` : ''}</td>
          <td data-label="Categoría">${esc(t.categoria)}</td>
          <td data-label="Estado">${stateBadge(t.estado)}</td>
          <td data-label="Ubicación">${esc(t.ubicacionTipo)}${t.ubicacionDetalle ? `<small class="text-muted">${esc(t.ubicacionDetalle)}</small>` : ''}</td>
          <td data-label="Responsable">${l ? `${esc(l.asignadoA)}<small>${dueBadge(l)}</small>` : '<span class="text-muted">—</span>'}</td>
          <td class="col-actions">${action}
            <button type="button" class="icon-btn" data-action="edit-tool" data-id="${t.id}" aria-label="Editar ${esc(t.sku)}" title="Editar">${icon('edit')}</button></td>
        </tr>`;
      }).join('')}</tbody></table></div>`;
  },

  // La búsqueda global solo redibuja la tabla para no perder el foco
  onSearch(el) { this.renderResults(el); },
};
