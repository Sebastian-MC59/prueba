/* Vista: Mantenimiento en curso, preventivos programados e historial. */
window.TM = window.TM || {};
TM.views = TM.views || {};

TM.views.mantenimiento = {
  title: 'Mantenimiento',
  searchPlaceholder: 'Buscar por código, herramienta, técnico o descripción',

  render(el) {
    const C = TM.config;
    const { icon, options } = TM.ui;
    el.innerHTML = `
      <section class="page-head">
        <div><h1>Mantenimiento</h1><p class="text-muted">Reparaciones, calibraciones y preventivos</p></div>
        <div class="page-actions">
          <button type="button" class="btn btn-primary" data-action="maintenance">${icon('plus')}Registrar mantenimiento</button>
        </div>
      </section>
      <div class="dash-grid">
        <section class="panel" id="maint-open"></section>
        <section class="panel" id="maint-due"></section>
      </div>
      <section class="panel panel-flush">
        <header class="panel-head"><h2>Historial</h2>
          <label class="filter"><span class="sr-only">Tipo</span>
            <select id="maint-type">${options([['', 'Todos los tipos'], ...C.tiposMantenimiento], TM.state.maintTipo)}</select></label>
        </header>
        <div id="maint-history"></div>
      </section>`;
    el.querySelector('#maint-type').addEventListener('change', e => { TM.state.maintTipo = e.target.value; this.renderResults(el); });
    this.renderResults(el);
  },

  renderResults(el) {
    const S = TM.store, U = TM.utils, C = TM.config;
    const { skuTag, maintDueBadge, empty } = TM.ui;
    const esc = U.esc;
    const q = TM.state.query;
    const matchTool = (t, extra = []) => t && U.matches(q, [t.sku, t.nombre, t.categoria, ...extra]);

    const open = S.openMaintenance().filter(m => matchTool(S.tool(m.toolId), [m.tipo, m.descripcion, m.tecnico]));
    el.querySelector('#maint-open').innerHTML = `
      <header class="panel-head"><h2>En curso</h2><span class="count-pill">${open.length}</span></header>
      ${open.length ? `<ul class="rows">${open.map(m => {
        const t = S.tool(m.toolId);
        const dias = U.daysBetween(m.fecha, U.today());
        return `<li class="row-item">
          <button type="button" class="row-main" data-action="detail" data-id="${t.id}">
            ${skuTag(t.sku)}<span class="row-text"><strong>${esc(t.nombre)}</strong><small>${esc(m.tipo)}: ${esc(m.descripcion)}</small></span>
          </button>
          <span class="badge tone-warn">${dias ? `Hace ${U.plural(dias, 'día', 'días')}` : 'Desde hoy'}</span>
          <button type="button" class="btn btn-small btn-secondary" data-action="complete-maint" data-id="${m.id}">Finalizar</button>
        </li>`;
      }).join('')}</ul>` : '<p class="panel-empty">No hay herramientas en el taller.</p>'}`;

    const due = S.maintenanceDue().filter(t => matchTool(t));
    el.querySelector('#maint-due').innerHTML = `
      <header class="panel-head"><h2>Preventivos programados</h2><span class="text-muted">Próximos ${C.diasAvisoMantenimiento} días y vencidos</span></header>
      ${due.length ? `<ul class="rows">${due.map(t => `<li class="row-item">
          <button type="button" class="row-main" data-action="detail" data-id="${t.id}">
            ${skuTag(t.sku)}<span class="row-text"><strong>${esc(t.nombre)}</strong><small>${U.fmtDate(t.proximoMantenimiento)}, ${esc(C.estados[t.estado].label.toLowerCase())}</small></span>
          </button>
          ${maintDueBadge(t.proximoMantenimiento)}
          <button type="button" class="btn btn-small btn-secondary" data-action="maintenance" data-id="${t.id}">Registrar</button>
        </li>`).join('')}</ul>` : '<p class="panel-empty">Nada programado. Define la fecha de próximo mantenimiento en cada herramienta para recibir avisos.</p>'}`;

    const history = S.maintenance()
      .filter(m => m.estado === 'completado' && (!TM.state.maintTipo || m.tipo === TM.state.maintTipo))
      .filter(m => matchTool(S.tool(m.toolId), [m.tipo, m.descripcion, m.tecnico]))
      .sort((a, b) => (b.fechaFin || b.fecha).localeCompare(a.fechaFin || a.fecha));
    const total = history.reduce((a, m) => a + (m.costo || 0), 0);

    el.querySelector('#maint-history').innerHTML = history.length ? `
      <div class="table-wrap table-plain"><table class="data">
        <thead><tr><th>Fecha</th><th>Herramienta</th><th>Tipo</th><th>Trabajo</th><th>Técnico</th><th class="num">Costo</th><th>Próximo</th></tr></thead>
        <tbody>${history.map(m => {
          const t = S.tool(m.toolId);
          return `<tr data-action="detail" data-id="${t.id}">
            <td data-label="Fecha">${U.fmtDate(m.fechaFin || m.fecha)}</td>
            <td data-label="Herramienta"><span class="cell-tool">${skuTag(t.sku)}<button type="button" class="cell-title" data-action="detail" data-id="${t.id}">${esc(t.nombre)}</button></span></td>
            <td data-label="Tipo">${esc(m.tipo)}</td>
            <td data-label="Trabajo" class="cell-wrap">${esc(m.descripcion)}${m.resultado === 'retirada' ? ' <span class="badge tone-muted">Retirada</span>' : ''}</td>
            <td data-label="Técnico">${esc(m.tecnico || '—')}</td>
            <td data-label="Costo" class="num">${U.money(m.costo)}</td>
            <td data-label="Próximo">${U.fmtDate(m.proximaFecha)}</td>
          </tr>`;
        }).join('')}</tbody>
        <tfoot><tr><td colspan="5">${U.plural(history.length, 'registro', 'registros')}</td><td class="num"><strong>${U.money(total)}</strong></td><td></td></tr></tfoot>
      </table></div>`
      : empty('Sin registros', q || TM.state.maintTipo ? 'Ningún mantenimiento coincide con la búsqueda.' : 'Los trabajos finalizados se guardan aquí con su costo y fecha.');
  },

  onSearch(el) { this.renderResults(el); },
};
