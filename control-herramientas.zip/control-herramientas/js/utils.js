/* Utilidades generales: fechas locales (YYYY-MM-DD), texto y formato. */
window.TM = window.TM || {};

TM.utils = (() => {
  const pad = n => String(n).padStart(2, '0');
  const toISO = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parse = s => {
    if (!s) return null;
    const [y, m, d] = s.split('-').map(Number);
    return new Date(y, m - 1, d);
  };

  const today = () => toISO(new Date());
  const addDays = (iso, n) => { const d = parse(iso); d.setDate(d.getDate() + n); return toISO(d); };
  const daysBetween = (a, b) => Math.round((parse(b) - parse(a)) / 86400000);

  const dateFmt = new Intl.DateTimeFormat('es', { day: 'numeric', month: 'short', year: 'numeric' });
  const fmtDate = iso => (iso ? dateFmt.format(parse(iso)) : '—');

  const moneyFmt = new Intl.NumberFormat('es', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  const money = n => (n === null || n === undefined || n === '' ? '—' : moneyFmt.format(Number(n)));

  const uid = prefix => `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;

  const esc = v => String(v ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // Normaliza para buscar sin importar mayúsculas ni tildes
  const norm = v => String(v ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

  // Todas las palabras de la búsqueda deben aparecer en alguno de los campos
  const matches = (query, fields) => {
    const terms = norm(query).split(/\s+/).filter(Boolean);
    if (!terms.length) return true;
    const haystack = norm(fields.filter(Boolean).join(' '));
    return terms.every(t => haystack.includes(t));
  };

  const debounce = (fn, ms = 120) => {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  };

  const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
  const bySku = (a, b) => a.sku.localeCompare(b.sku, 'es', { numeric: true });

  return { today, addDays, daysBetween, fmtDate, money, uid, esc, norm, matches, debounce, plural, bySku };
})();
